﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Visitor_SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Hostel obj = new Hostel();
        obj.ReadData("select * from login where uname='" + txtuname.Text + "' AND pwd='" + txtpwd.Text + "'");
        if (obj.dr.Read())
        {
            string utype = obj.dr["utype"].ToString();
            if (utype == "admin")
            {
                Session["uname"] = txtuname.Text;
                Response.Redirect("~/admin/AdminHome.aspx");
            }
            else if (utype == "Staff")
            {
                Session["uname"] = txtuname.Text;
                obj.ReadData("select empid,fname from employee where uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Session["empid"] = obj.dr["empid"].ToString();
                    Session["fname"] = obj.dr["fname"].ToString();
                }
                Response.Redirect("~/Staff/Staffhome.aspx");
            }
            else if (utype == "Warden")
            {
                Session["uname"] = txtuname.Text;
                obj.ReadData("select empid,fname,fname+' '+lname as name from employee where uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Session["empid"] = obj.dr["empid"].ToString();
                    Session["fname"] = obj.dr["fname"].ToString();
                    Session["name"] = obj.dr["name"].ToString();
                }
                Response.Redirect("~/Warden/Wardenhome.aspx");
            }
            else if (utype == "Contractor")
            {
                Session["uname"] = txtuname.Text;
                obj.ReadData("select fname+' '+lname as name from contractor where uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Session["name"] = obj.dr["name"].ToString();
                }
                Response.Redirect("~/contractor/contractorhome.aspx");
            }
            else if (utype == "Student")
            {
                Session["uname"] = txtuname.Text;
                obj.ReadData("select admno,name from student where status='Active' and uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Session["uname"] = obj.dr["admno"].ToString();
                    Session["admno"] = obj.dr["admno"].ToString();
                    Session["name"] = obj.dr["name"].ToString();
                    Response.Redirect("~/student/studenthome.aspx");
                }
                obj.ReadData("select admno,email,name from student where status='Pending' and uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Session["uname"] = obj.dr["admno"].ToString();
                    Session["admno"] = obj.dr["admno"].ToString();
                    Session["email"] = obj.dr["email"].ToString();
                    Session["name"] = obj.dr["name"].ToString();
                    Response.Redirect("~/student/ResetPwd.aspx");
                }
            }
        }
        else
        {
            Response.Write("<script>alert('invalid login')</script>");
        }
    }
}