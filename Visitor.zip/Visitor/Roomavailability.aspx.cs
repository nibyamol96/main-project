﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Visitor_Roomavailability : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from roomdetails,beddetails where roomdetails.roomno=beddetails.roomno and beddetails.status='AVAILABLE'", GridView1);
        }
    }
}