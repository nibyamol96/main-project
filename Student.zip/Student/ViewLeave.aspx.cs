﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewLeave : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from leave_student,student where leave_student.admno=student.admno and leave_student.admno='" + (String)Session["uname"] + "'", GridView1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
       
    }
}