﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Employee_leaveapp : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtdate.Text = System.DateTime.Now.Date.ToShortDateString();
        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into leave_student values('" + (String)Session["uname"] + "','" + txtdate.Text + "','" + txfdate.Text + "','" + txttdate.Text + "','" + txttotaldys.Text + "','" + txtleavefor.Text + "','pending')");
        Response.Write(obj.MessageBox("leave details Added Successfully"));
        Server.Transfer("leaveapp.aspx");
    }
    protected void txfdate_TextChanged(object sender, EventArgs e)
    {
        DateTime fdate = Convert.ToDateTime(txfdate.Text);
        if (fdate < System.DateTime.Now.Date)
        {
            txfdate.Text = System.DateTime.Now.Date.ToShortDateString();
            Response.Write(obj.MessageBox("Invalid From Date"));
        }
        else
        {
            txttdate.Text = txfdate.Text;
        }
    }
    protected void txttdate_TextChanged(object sender, EventArgs e)
    {
        DateTime fdate = Convert.ToDateTime(txfdate.Text);
        DateTime tdate = Convert.ToDateTime(txttdate.Text);
        if (tdate < fdate)
        {
            txttdate.Text = txfdate.Text;
            Response.Write(obj.MessageBox("Invalid To Date"));
        }
        else
        {
            txttotaldys.Text = Convert.ToString(tdate.Day - fdate.Day);
        }
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnclear_Click(object sender, EventArgs e)
    {
        Server.Transfer("leaveapp.aspx");
    }
}