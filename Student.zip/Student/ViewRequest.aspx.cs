﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_ViewRequest : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select *,contractor.fname+' '+contractor.lname as name from Food_Request,contractor where Food_Request.contractor=contractor.uname and Food_Request.uname='" + (String)Session["uname"] + "' and Food_Request.status='Active'", GridView2);
        }
    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        obj.WriteData("update Food_Request set status='Cancelled' where reqid=" + e.CommandArgument.ToString());
        Response.Write(obj.MessageBox("Food Request cancelled successfully"));
        Server.Transfer("ViewReqeust.aspx");
    }
}