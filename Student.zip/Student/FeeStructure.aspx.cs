﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FeeStructure : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select *,floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,Student where allocation.admno=student.admno and allocation.status='Allocated' and student.uname='" + (String)Session["uname"] + "'", GridView1);
            obj.ReadData("select sum(food.rate)*4 as amount from food,foodmenu,foodmenudetails where foodmenudetails.fmid=foodmenu.fmid and foodmenudetails.fid=food.fid");
            if (obj.dr.Read())
            {
                lblamount.Text = obj.dr.GetValue(0).ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}