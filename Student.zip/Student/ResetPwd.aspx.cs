﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_ResetPwd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Hostel obj = new Hostel();
        if (txtconfirm.Text == txtpwd.Text)
        {
            obj.WriteData("update student set status='Active' where uname='" + (String)Session["uname"] + "'");
            obj.WriteData("update Login set Pwd='" + txtpwd.Text + "' where Uname='" + (String)Session["uname"] + "'");
            Response.Write(obj.MessageBox("Password Updated"));
            Server.Transfer("StudentHome.aspx");
        }
        else
        {
            Response.Write(obj.MessageBox("Password Mismatch"));
        }
    }
}