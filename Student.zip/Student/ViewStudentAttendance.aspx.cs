﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Staff_ViewStudentAttendance : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {

    }
    protected void Button4_Click(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select * from attendance,student where attendance.admno=student.admno and attendance.admno='" + (String)Session["uname"] + "' " +
            " and month(attendance.atdate)=" + ddlmonth.SelectedItem.Value + " and year(attendance.atdate)=" + System.DateTime.Now.Year.ToString(), GridView1);
        if (obj.dt.Rows.Count == 0)
        {
            Response.Write(obj.MessageBox("No Data Exists!!!"));
            Server.Transfer("ViewStudentAttendance.aspx");
        }
        else
        {
            obj.ReadData("select count(*) from attendance where attendence='Absent' and admno='" + (String)Session["uname"] + "' and " +
                " month(attendance.atdate)=" + ddlmonth.SelectedItem.Value + " and year(attendance.atdate)=" + System.DateTime.Now.Year.ToString());
            if (obj.dr.Read())
            {
                lblmsg.Text = "Total Absent Count of this Month is " + obj.dr.GetValue(0).ToString();
            }
        }
    }
}