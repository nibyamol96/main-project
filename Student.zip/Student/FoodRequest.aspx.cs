﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_FoodRequest : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("fname", "uname", "contractor", "", ddlfoodcontractor);
        }
    }
    protected void txtfdate_TextChanged(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(txtfdate.Text);
        if (dtm < System.DateTime.Now.Date)
        {
            Response.Write(obj.MessageBox("INVLAID FROM DATE"));
            txtfdate.Text = "";
        }
    }
    protected void txttdate_TextChanged(object sender, EventArgs e)
    {
        DateTime sdate = Convert.ToDateTime(txtfdate.Text);
        DateTime edate = Convert.ToDateTime(txttdate.Text);
        if (edate < sdate)
        {
            Response.Write(obj.MessageBox("INVLAID TO DATE"));
            txttdate.Text = "";
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from Food_Request where uname='" + (String)Session["uname"] + "' and contractor='" + ddlfoodcontractor.SelectedValue + "' and status='Active'");
        if (obj.dr.Read())
        {
            Response.Write(obj.MessageBox("Request already send to this Contractor"));
        }
        else
        {
            string BF = "NO", LUN = "NO", TEA = "NO", DIN = "NO";
            foreach (ListItem li in CheckBoxList1.Items)
            {
                if (li.Selected == true)
                {
                    if (li.Value == "1")
                    {
                        BF = "YES";
                    }
                    if (li.Value == "2")
                    {
                        LUN = "YES";
                    }
                    if (li.Value == "3")
                    {
                        TEA = "YES";
                    }
                    if (li.Value == "4")
                    {
                        DIN = "YES";
                    }
                }
            }
            obj.WriteData("insert into Food_Request values('" + (String)Session["uname"] + "','" + ddlfoodcontractor.SelectedValue + "','" + txtfdate.Text + "','" + txttdate.Text + "','" + BF + "','" + LUN + "','" + TEA + "','" + DIN + "','Active')");
            Response.Write(obj.MessageBox("Request send Successfully"));
            Server.Transfer("ViewRequest.aspx");
        }
    }
}