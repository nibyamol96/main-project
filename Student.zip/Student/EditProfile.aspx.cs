﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net;

public partial class EditProfile : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.ReadData("select * from Student where admno=" + (String)Session["uname"]);
            if (obj.dr.Read())
            {
                txt_address.Text = obj.dr["address"].ToString();
                txt_admno.Text = obj.dr["admno"].ToString();
                txt_dob.Text = obj.dr["dob"].ToString();
                txt_email.Text = obj.dr["email"].ToString();
                txt_name.Text = obj.dr["name"].ToString();
                txt_phone.Text = obj.dr["phone"].ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/Photo/" + FileUpload1.FileName));
            obj.ReadData("update student set name='" + txt_name.Text + "',address='" + txt_address.Text + "',phone=" + txt_phone.Text + ",email='" + txt_email.Text + "',dob='" + txt_dob.Text + "',course='" + ddl_course.SelectedItem.Text + "',sem=" + ddl_sem.SelectedItem.Text + ",photo='" + FileUpload1.FileName + "' where admno=" + (String)Session["uname"]);
        }
        else
        {
            obj.ReadData("update student set name='" + txt_name.Text + "',address='" + txt_address.Text + "',phone=" + txt_phone.Text + ",email='" + txt_email.Text + "',dob='" + txt_dob.Text + "',course='" + ddl_course.SelectedItem.Text + "',sem=" + ddl_sem.SelectedItem.Text + " where admno=" + (String)Session["uname"]);
        }
        Response.Write(obj.MessageBox("Profile Updated successfully"));
        Server.Transfer("ViewProfile.aspx");
    }
    protected void txt_phone_TextChanged(object sender, EventArgs e)
    {
         
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail()
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = txt_email.Text;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = "";
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
    protected void txt_admno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtfdate_TextChanged(object sender, EventArgs e)
    {
         
    }
    protected void txttdate_TextChanged(object sender, EventArgs e)
    {
         
    }
}