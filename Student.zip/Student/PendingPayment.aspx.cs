﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PendingPayment : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select student.name,student.phone,allocation.floor,allocation.roomno,allocation.bedno,allocation.tmonths,floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,student where allocation.status='Allocated' and allocation.admno=student.admno and student.admno='" + (String)Session["uname"] + "' and student.admno not in(select admno from payment where month(pdate)=" + System.DateTime.Now.Month.ToString() + ")", GridView1);
            if (obj.dt.Rows.Count == 0)
            {
                Response.Write(obj.MessageBox("No Record Exists!!!"));
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}