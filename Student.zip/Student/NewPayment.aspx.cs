﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class NewPayment : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            int CDay = System.DateTime.Now.Day;
            double messamount = 0, cutamount = 0, fineamount = 0, roomrent = 0, advance = 0;
            int attcount = 0, tmonths = 0, pmonths = 0, rmonths = 0;
            obj.ReadData("select tmonths,advance from allocation where admno='" + (String)Session["uname"] + "'");
            if (obj.dr.Read())
            {
                tmonths = Convert.ToInt32(obj.dr.GetValue(0).ToString());
                advance = Convert.ToDouble(obj.dr.GetValue(1).ToString());
            }
            obj.ReadData("select count(*) from payment where admno='" + (String)Session["uname"] + "'");
            if (obj.dr.Read())
            {
                pmonths = Convert.ToInt32(obj.dr.GetValue(0).ToString());
            }
            rmonths = tmonths - pmonths;
            obj.ReadData("select floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,student where allocation.status='Allocated' and allocation.admno=student.admno and student.admno='" + (String)Session["uname"] + "' and student.admno not in(select admno from payment where month(pdate)=" + System.DateTime.Now.Month.ToString() + ")");
            if (obj.dr.Read())
            {
                roomrent = Convert.ToDouble(obj.dr.GetValue(0).ToString());
            }
            lblfeespaid.Text = Convert.ToString(roomrent * pmonths);
            lblfeespending.Text = Convert.ToString(roomrent * rmonths);
            lblfeesadvance.Text = Convert.ToString(advance);
            obj.FillGrid("select student.admno,student.name,student.phone,allocation.floor,allocation.roomno,allocation.bedno,allocation.tmonths,floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,student where allocation.status='Allocated' and allocation.admno=student.admno and student.admno='" + (String)Session["uname"] + "' and student.admno not in(select admno from payment where month(pdate)=" + System.DateTime.Now.Month.ToString() + ")", GridView1);
            if (obj.dt.Rows.Count == 0)
            {
                Panel1.Visible = false;
                Response.Write(obj.MessageBox("No Record Exists!!!"));
            }
            else
            {
                obj.ReadData("select floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,student where allocation.status='Allocated' and allocation.admno=student.admno and student.admno='" + (String)Session["uname"] + "' and student.admno not in(select admno from payment where month(pdate)=" + System.DateTime.Now.Month.ToString() + ")");
                if (obj.dr.Read())
                {
                    roomrent = Convert.ToDouble(obj.dr.GetValue(0).ToString());
                }
                Panel1.Visible = true;
                obj.ReadData("select sum(food.rate)*4 as amount from food,foodmenu,foodmenudetails where foodmenudetails.fmid=foodmenu.fmid and foodmenudetails.fid=food.fid");
                if (obj.dr.Read())
                {
                    messamount = Convert.ToDouble(obj.dr.GetValue(0).ToString());
                }
                obj.ReadData("select count(*) from studentattendance where admno=" + (String)Session["uname"] + " and month(adate)=" + System.DateTime.Now.Month.ToString());
                if (obj.dr.Read())
                {
                    attcount = Convert.ToInt32(obj.dr.GetValue(0).ToString());
                }

                DateTime dtm_temp = new DateTime();
                obj.ReadData("select adate from Student,allocation where Student.admno=allocation.admno and Student.admno=" + (String)Session["uname"]);
                if (obj.dr.Read())
                {
                    dtm_temp = Convert.ToDateTime(obj.dr.GetValue(0).ToString());
                }
                if (dtm_temp.Month == System.DateTime.Now.Month)
                {
                    lblmessfees.Text = messamount.ToString();
                    lblmesscut.Text = "0.0";
                    lbltotal.Text = messamount.ToString();
                    fineamount = 0;
                    lblfine.Text = fineamount.ToString();
                    lblroomrent.Text = roomrent.ToString();
                    lblfinaltotal.Text = Convert.ToString(roomrent + messamount + fineamount);
                }
                else
                {
                    if (attcount < 20)
                    {
                        cutamount = messamount / 2;
                        lblmessfees.Text = messamount.ToString();
                        lblmesscut.Text = cutamount.ToString();
                        lbltotal.Text = cutamount.ToString();
                    }
                    else
                    {
                        lblmessfees.Text = messamount.ToString();
                        lblmesscut.Text = "0.0";
                        lbltotal.Text = messamount.ToString();
                    }
                    if (CDay > 10)
                    {
                        fineamount = 25 * (CDay - 10);
                    }
                    else
                    {
                        fineamount = 0;
                    }
                    lblfine.Text = fineamount.ToString();
                    lblroomrent.Text = roomrent.ToString();
                    lblfinaltotal.Text = Convert.ToString(roomrent + messamount + fineamount);
                }
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        
    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        double amt = 0.0;
        obj.ReadData("select floor((allocation.total-allocation.advance)/allocation.tmonths) as amount,roomno,bedno from allocation,student where allocation.status='Allocated' and allocation.admno=student.admno and student.admno='" + (String)Session["uname"] + "' and student.admno not in(select admno from payment where month(pdate)=" + System.DateTime.Now.Month.ToString() + ")");
        if (obj.dr.Read())
        {
            amt = Convert.ToDouble(obj.dr.GetValue(0).ToString());
            Session["roomno"] = obj.dr.GetValue(1).ToString();
            Session["bedno"] = obj.dr.GetValue(2).ToString();
        }
        Session["amount"] = Convert.ToString(Convert.ToDouble(lblfinaltotal.Text));
        obj.WriteData("insert into payment values('" + System.DateTime.Now.Date.ToShortDateString() + "','" + (String)Session["uname"] + "','" + (String)Session["roomno"] + "','" + (String)Session["bedno"] + "','" + (String)Session["amount"] + "','" + lbltotal.Text + "')");
        Response.Redirect("~/Banking/User/Home.aspx");
    }
}