﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Complaints_Suggestions : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Hostel obj = new Hostel();
        obj.WriteData("insert into compaints_suggestions values('" + (String)Session["uname"] + "','" + System.DateTime.Now.Date + "','" + txtfeedback.Text + "')");
        Response.Write(obj.MessageBox("Complaints & Suggestions added successfully"));
        Server.Transfer("Complaints_Suggestions.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("Complaints_Suggestions.aspx");
    }
}