﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Collections;

public partial class Student_FoodMenu : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    public static DataTable dt_temp = new DataTable();
    public static ArrayList arrlst_day = new ArrayList();
    public static ArrayList arrlst_fmid = new ArrayList();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            dt_temp.Columns.Clear();
            dt_temp.Columns.Add("Day");
            dt_temp.Columns.Add("Breakfast");
            dt_temp.Columns.Add("Lunch");
            dt_temp.Columns.Add("Tea");
            dt_temp.Columns.Add("Supper");
            FoodMenu();
        }
    }
    protected void FoodMenu()
    {
        dt_temp.Rows.Clear();
        arrlst_day.Clear();
        arrlst_fmid.Clear();
        obj.ReadData("select distinct fday,fmid from foodmenu");
        while (obj.dr.Read())
        {
            arrlst_day.Add(obj.dr.GetValue(0).ToString());
            arrlst_fmid.Add(obj.dr.GetValue(1).ToString());
        }
        for (int i = 0; i < arrlst_fmid.Count; i++)
        {
            DataRow drw = dt_temp.NewRow();
            drw[0] = arrlst_day[i].ToString();
            obj.ReadData("select session,fname from foodmenudetails,food where foodmenudetails.fid=food.fid and foodmenudetails.fmid=" + arrlst_fmid[i].ToString());
            while (obj.dr.Read())
            {
                if (obj.dr["session"].ToString() == "Breakfast")
                {
                    drw[1] = obj.dr["fname"].ToString();
                }
                else if (obj.dr["session"].ToString() == "Lunch")
                {
                    drw[2] = obj.dr["fname"].ToString();
                }
                else if (obj.dr["session"].ToString() == "Tea")
                {
                    drw[3] = obj.dr["fname"].ToString();
                }
                else if (obj.dr["session"].ToString() == "Supper")
                {
                    drw[4] = obj.dr["fname"].ToString();
                }
            }
            dt_temp.Rows.Add(drw);
        }
        GridView2.DataSource = dt_temp;
        GridView2.DataBind();
    }
}