﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Warden_Print_Stud : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblfloor.Text = (String)Session["floor"];
            lblusers.Text = (String)Session["users"];
            lblroomno.Text = (String)Session["roomno"];
            lblbedno.Text = (String)Session["bedno"];
            lblRoomrent.Text = (String)Session["roomrent"];
            lblBedrent.Text = (String)Session["bedrent"];

            txt_admno.Text = (String)Session["admno"];
            txt_name.Text = (String)Session["name"];
            txt_address.Text = (String)Session["address"];
            txt_gender.Text = (String)Session["gender"];
            txt_dob.Text = (String)Session["dob"];
            txt_course.Text = (String)Session["course"];
            txt_sem.Text = (String)Session["sem"];
            txt_phone.Text = (String)Session["mobile"];
            txt_email.Text = (String)Session["email"];
            txt_uname.Text = (String)Session["uname"];
            txt_pwd.Text = (String)Session["pwd"];
            txtfdate.Text = (String)Session["fdate"];
            txttdate.Text = (String)Session["tdate"];
            lbldays.Text = (String)Session["days"];
            lblmonths.Text = (String)Session["month"];
            txtamount.Text = (String)Session["amount"];
            txtadvance.Text = (String)Session["advance"];
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session["ctrl"] = Panel1;
        ClientScript.RegisterStartupScript(this.GetType(), "onclick", "<script language=javascript>window.open('Print.aspx','PrintMe','height=1300px,width=1300px,scrollbars=1');</script>");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Session["amount"] = txtadvance.Text;
        Response.Redirect("~/Banking/User/Home.aspx");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["amount"] = txtadvance.Text;
        Response.Redirect("Challan.aspx");
    }
}