﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FeeStructure : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("floor", "floor", "roomdetails", "", ddl_floor);
            obj.FillGrid("select beddetails.roomno,beddetails.bedno,floor,rent,noofusers,floor((rent)/noofusers) as bedrent,beddetails.status from roomdetails,beddetails where beddetails.roomno=roomdetails.roomno", GridView1);
            obj.ReadData("select sum(food.rate)*4 as amount from food,foodmenu,foodmenudetails where foodmenudetails.fmid=foodmenu.fmid and foodmenudetails.fid=food.fid");
            if (obj.dr.Read())
            {
                lblamount.Text = obj.dr.GetValue(0).ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select beddetails.roomno,beddetails.bedno,floor,rent,noofusers,floor((rent)/noofusers) as bedrent,beddetails.status from roomdetails,beddetails where beddetails.roomno=roomdetails.roomno and roomdetails.noofusers=" + ddl_users.SelectedItem.Text + " and roomdetails.floor=" + ddl_floor.SelectedItem.Text, GridView1);
        if (obj.dt.Rows.Count == 0)
        {
            Response.Write(obj.MessageBox("No Record Exists!!!"));
        }
    }
}