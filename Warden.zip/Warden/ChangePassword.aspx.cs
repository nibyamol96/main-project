﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Staff_ChangePassword : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void clear()
    {
        txtcurrent.Text = "";
        txtnew.Text = "";
        txtconfirm.Text = "";
    }

    protected void btncancel_Click(object sender, EventArgs e)
    {
        clear();
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        obj.WriteData("update Login set pwd='" + txtnew.Text+ "'where uname='" + (String)Session["uname"] + "'"); 
        Response.Write("<script>alert('Password Updated')</script>");
        clear();
    }
}