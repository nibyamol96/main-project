﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net;

public partial class Instructor_Reg : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("floor", "floor", "roomdetails", "", ddl_floor);
            Panel1.Visible = false;
            Panel2.Visible = false;
            obj.FillGrid("select beddetails.roomno,beddetails.bedno,floor,rent,noofusers,floor((rent)/noofusers) as bedrent,beddetails.status from roomdetails,beddetails where beddetails.roomno=roomdetails.roomno and beddetails.status='AVAILABLE'", GridView1);
            
            obj.ReadData("select isnull(max(admno)+1,257525) from Student");
            if (obj.dr.Read())
            {
                txt_admno.Text = obj.dr.GetValue(0).ToString();
                txt_uname.Text = txt_admno.Text;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into Student values(" + txt_admno.Text + ",'" + txt_name.Text + "','" + txt_address.Text + "','" + txt_phone.Text + "','" + txt_email.Text + "'," +
            "'Female','" + txt_dob.Text + "','" + ddl_course.SelectedItem.Text + "','" + ddl_sem.SelectedItem.Text + "'," +
            "'" + txt_admno.Text + "','Pending','" + (String)Session["photo"] + "','" + txt_pname.Text + "','" + txt_pemail.Text + "','" + txt_pphone.Text + "')");
        obj.WriteData("insert into Login values('" + txt_uname.Text + "','" + txt_pwd.Text + "','Student')");
        obj.WriteData("insert into allocation values('" + lblfloor.Text + "','" + lblroomno.Text + "','" + lblbedno.Text + "','" + txt_admno.Text + "','" + System.DateTime.Now.Date.ToShortDateString() + "','" + txtfdate.Text + "','" + txttdate.Text + "','" + lblBedrent.Text + "','" + lbldays.Text + "','" + lblmonths.Text + "','" + txtamount.Text + "','" + txtadvance.Text + "','Allocated')");
        obj.WriteData("update beddetails set status='NOT AVAILABLE' where roomno='" + lblroomno.Text + "' and bedno='" + lblbedno.Text + "'");
        SentoMail();
        Response.Write(obj.MessageBox("Registration completed successfully"));

        Session["admno"] = txt_admno.Text;
        Session["name"] = txt_name.Text;
        Session["address"] = txt_address.Text;
        Session["gender"] = "Female";
        Session["dob"] = txt_dob.Text;
        Session["course"] = ddl_course.SelectedItem.Text;
        Session["sem"] = ddl_sem.SelectedItem.Text;
        Session["mobile"] = txt_phone.Text;
        Session["email"] = txt_email.Text;
        Session["uname"] = txt_uname.Text;
        Session["pwd"] = txt_pwd.Text;
        Session["fdate"] = txtfdate.Text;
        Session["tdate"] = txttdate.Text;
        Session["days"] = lbldays.Text;
        Session["month"] = lblmonths.Text;
        Session["amount"] = txtamount.Text;
        Session["advance"] = txtadvance.Text;

        Server.Transfer("Print_Stud.aspx");
    }
    protected void txt_phone_TextChanged(object sender, EventArgs e)
    {
        txt_pwd.Text = txt_phone.Text;
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail()
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = txt_email.Text;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = "USERNAME FOR LOGIN IS " + txt_uname.Text + " AND YOUR PASSWORD IS " + txt_pwd.Text;
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
    protected void txt_admno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtfdate_TextChanged(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(txtfdate.Text);
        if (dtm < System.DateTime.Now.Date)
        {
            Response.Write(obj.MessageBox("INVLAID FROM DATE"));
            txtfdate.Text = "";
        }
    }
    protected void txttdate_TextChanged(object sender, EventArgs e)
    {
        DateTime sdate = Convert.ToDateTime(txtfdate.Text);
        DateTime edate = Convert.ToDateTime(txttdate.Text);
        if (edate < sdate)
        {
            Response.Write(obj.MessageBox("INVLAID TO DATE"));
            txttdate.Text = "";
            lbldays.Text = "";
            lblmonths.Text = "";
            txtamount.Text = "";
        }
        else
        {
            lbldays.Text = Convert.ToString((edate - sdate).TotalDays);
            lblmonths.Text = Convert.ToString(Convert.ToInt64(edate.Subtract(sdate).Days / (365.25 / 12)));
            txtamount.Text = Convert.ToString(Convert.ToDouble(lblmonths.Text) * Convert.ToDouble(lblBedrent.Text));
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Session["photo"] = FileUpload1.FileName;
        FileUpload1.SaveAs(Server.MapPath("~/Photo/" + FileUpload1.FileName));
        Panel1.Visible = true;
        obj.FillDropDownList("roomno", "roomno", "roomdetails", "floor=" + ddl_floor.SelectedItem.Text + " and status='AVAILABLE'", ddl_roomno);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session["floor"] = ddl_floor.SelectedItem.Text;
        Session["users"] = "3";
        Session["roomno"] = ddl_roomno.SelectedItem.Text;
        Session["bedno"] = ddl_bedno.SelectedItem.Text;
        Session["roomrent"] = lblRoomrent.Text;
        Session["bedrent"] = lblBedrent.Text;
        Panel2.Visible = true;
        lblfloor.Text = (String)Session["floor"];
        lblusers.Text = (String)Session["users"];
        lblroomno.Text = (String)Session["roomno"];
        lblbedno.Text = (String)Session["bedno"];
        lblRoomrent.Text = (String)Session["roomrent"];
        lblBedrent.Text = (String)Session["bedrent"];

    }
    protected void ddl_roomno_SelectedIndexChanged(object sender, EventArgs e)
    {
        obj.FillDropDownList("bedno", "bid", "beddetails", "roomno='" + ddl_roomno.SelectedItem.Text + "' and status='AVAILABLE'", ddl_bedno);
        obj.ReadData("select noofusers,rent from roomdetails where roomno='" + ddl_roomno.SelectedItem.Text + "'");
        if (obj.dr.Read())
        {
            lblRoomrent.Text = obj.dr["rent"].ToString();
            lblBedrent.Text = Convert.ToString(Convert.ToDouble(obj.dr["rent"].ToString()) / Convert.ToDouble(obj.dr["noofusers"].ToString()));
        }
    }
}