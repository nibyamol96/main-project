﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class compaints_suggestions : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            catdetails();
        }
    }

    void catdetails()
    {
        obj.adapter("select * from compaints_suggestions,student where student.uname=compaints_suggestions.uname");
        if (obj.dt.Rows.Count > 0)
        {
            GridView1.DataSource = obj.dt;
            GridView1.DataBind();
        }
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        catdetails();
    }

    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        catdetails();
    }

    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
         
    }

    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        obj.WriteData("delete from compaints_suggestions where id=" + GridView1.DataKeys[e.RowIndex].Value);
        Response.Write(obj.MessageBox("Deleted Successfully"));
        Server.Transfer("viewcompaints_suggestions.aspx");
    }
}