﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddVisitorsList : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtdate.Text = System.DateTime.Now.Date.ToString();
            obj.FillDropDownList("name", "admno", "student", "", DropDownList1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into visitorslist values('" + txtdate.Text + "','" + DropDownList1.SelectedValue + "','" + txtftime.Text + "','" + txttotime.Text + "','" + txtname.Text + "','" + txtcontact.Text + "')");
        Response.Write(obj.MessageBox("Visitors List Added Successfully"));
        Server.Transfer("VisitorsList.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("VisitorsList.aspx");
    }
}