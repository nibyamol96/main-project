﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Warden_SearchRoom : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("floor", "floor", "roomdetails", "", ddl_floor);
            Panel1.Visible = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        obj.FillDropDownList("roomno", "roomno", "roomdetails", "floor=" + ddl_floor.SelectedItem.Text + " and noofusers=" + ddl_users.SelectedItem.Text + " and status='AVAILABLE'", ddl_roomno);
    }
    protected void ddl_roomno_SelectedIndexChanged(object sender, EventArgs e)
    {
        obj.FillDropDownList("bedno", "bid", "beddetails", "roomno='" + ddl_roomno.SelectedItem.Text + "' and status='AVAILABLE'", ddl_bedno);
        obj.ReadData("select noofusers,rent from roomdetails where roomno='" + ddl_roomno.SelectedItem.Text + "'");
        if (obj.dr.Read())
        {
            lblRoomrent.Text = obj.dr["rent"].ToString();
            lblBedrent.Text = Convert.ToString(Convert.ToDouble(obj.dr["rent"].ToString()) / Convert.ToDouble(obj.dr["noofusers"].ToString()));
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Session["floor"] = ddl_floor.SelectedItem.Text;
        Session["users"] = ddl_users.SelectedItem.Text;
        Session["roomno"] = ddl_roomno.SelectedItem.Text;
        Session["bedno"] = ddl_bedno.SelectedItem.Text;
        Session["roomrent"] = lblRoomrent.Text;
        Session["bedrent"] = lblBedrent.Text;
        Response.Redirect("Student_Reg.aspx");
    }
}