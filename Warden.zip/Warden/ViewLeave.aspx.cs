﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net;

public partial class ViewLeave : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from leave_student,student where leave_student.admno=student.admno and leave_student.status='pending'", GridView1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        string email = "";
        obj.ReadData("select distinct student.pemail,Student.name,leave_student.fdate,leave_student.tdate,leave_student.lfor from leave_student,student where leave_student.admno=student.admno and leave_student.lvid=" + e.CommandArgument.ToString());
        if (obj.dr.Read())
        {
            email = obj.dr.GetValue(0).ToString();
            Session["lv"]= obj.dr.GetValue(1).ToString() + " is taking leave from "+ obj.dr.GetValue(2).ToString()+" to "+ obj.dr.GetValue(3).ToString()+" for "+ obj.dr.GetValue(4).ToString();
        }
        SentoMail(email);
        obj.WriteData("update leave_student set status='approved' where lvid=" + e.CommandArgument.ToString());
        Response.Write(obj.MessageBox("Leave Approved Successfully"));
        Server.Transfer("ViewLeave.aspx");
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail(string email)
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = email;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = (String)Session["lv"];
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
}