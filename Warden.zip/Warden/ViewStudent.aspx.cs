﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Warden_SearchStudent : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from allocation,Student where allocation.admno=student.admno", GridView1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
}