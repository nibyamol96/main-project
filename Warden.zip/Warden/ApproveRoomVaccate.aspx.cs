﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MyRoom : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Panel1.Visible = false;
            obj.FillGrid("select * from allocation,Student where allocation.admno=student.admno and allocation.status='pending'", GridView1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        string roomno = "", bedno = "";
        obj.ReadData("select roomno,bedno from allocation where admno='" + e.CommandArgument.ToString() + "'");
        if (obj.dr.Read())
        {
            roomno = obj.dr.GetValue(0).ToString();
            bedno = obj.dr.GetValue(1).ToString();
        }
        obj.WriteData("update allocation set status='Vaccated' where admno=" + e.CommandArgument.ToString());
        obj.WriteData("update beddetails set status='AVAILABLE' where roomno='" + roomno + "' and bedno='" + bedno + "'");
        Response.Write(obj.MessageBox("Request send successfully"));
        Server.Transfer("MyRoom.aspx");
    }

    protected void LinkButton2_Command(object sender, CommandEventArgs e)
    {
        Panel1.Visible = true;
        int tmonths = 0, pmonths = 0;
        double amt = 0.0, tamount = 0.0;
        obj.ReadData("select fdate,tdate,tmonths from allocation where admno=" + e.CommandArgument.ToString());
        if (obj.dr.Read())
        {
            lblfdate.Text = obj.dr.GetValue(0).ToString();
            lbltdate.Text = obj.dr.GetValue(1).ToString();
            tmonths = Convert.ToInt32(obj.dr.GetValue(2).ToString());
        }
        obj.ReadData("select count(*) from payment where admno=" + e.CommandArgument.ToString());
        if (obj.dr.Read())
        {
            pmonths = Convert.ToInt32(obj.dr.GetValue(0).ToString());
        }
        obj.ReadData("select floor((allocation.total-allocation.advance)/allocation.tmonths) as amount from allocation,student where allocation.admno=student.admno and student.admno=" + e.CommandArgument.ToString());
        if (obj.dr.Read())
        {
            amt = Convert.ToDouble(obj.dr.GetValue(0).ToString());
        }
        int dmonth = tmonths - pmonths;
        tamount = dmonth * amt;
        lblpendingfees.Text = tamount.ToString();
    }
}