﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewLeave : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("name", "admno", "student", "", DropDownList1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {

    }
    protected void Button1_Click1(object sender, EventArgs e)
    {
        obj.FillGrid("select * from visitorslist where admno='" + DropDownList1.SelectedValue + "'", GridView1);
    }
}