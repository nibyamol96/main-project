﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_viewattendence : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select admno,name from Student order by name asc", GridView1);
            TextBox1.Text = System.DateTime.Now.Date.ToShortDateString();
            obj.FillGrid("select student.name,leave_student.fdate,leave_student.tdate from leave_student,student where leave_student.admno=student.admno and '" + TextBox1.Text + "' BETWEEN CONVERT(date,leave_student.fdate) and CONVERT(date,leave_student.tdate)", GridView2);
            if (obj.dt.Rows.Count > 0)
            {
                Panel1.Visible = true;
            }
            else
            {
                Panel1.Visible = false;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from attendance where atdate='" + TextBox1.Text + "'");
        if (obj.dr.Read())
        {
            Response.Write(obj.MessageBox("Attendance already added for this date"));
        }
        else
        {
            foreach (GridViewRow grw in GridView1.Rows)
            {
                RadioButtonList rbtn = (RadioButtonList)grw.Cells[2].Controls[0].FindControl("RadioButtonList1");
                Label lblempid = (Label)grw.Cells[0].Controls[0].FindControl("Label1");
                obj.WriteData("insert into attendance values( '" + TextBox1.Text + "','" + lblempid.Text + "','" + rbtn.SelectedItem.Text + "')");
            }
            Response.Write(obj.MessageBox("Attendance added successfully"));
            Server.Transfer("Attendance.aspx");
        }
    }
}