﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net;

public partial class Instructor_Reg : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblfloor.Text = (String)Session["floor"];
            lblusers.Text = (String)Session["users"];
            lblroomno.Text = (String)Session["roomno"];
            lblbedno.Text = (String)Session["bedno"];
            lblRoomrent.Text = (String)Session["roomrent"];
            lblBedrent.Text = (String)Session["bedrent"];

            obj.ReadData("select isnull(max(admno)+1,257525) from Student");
            if (obj.dr.Read())
            {
                txt_admno.Text = obj.dr.GetValue(0).ToString();
                txt_uname.Text = txt_admno.Text;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into Student values(" + txt_admno.Text + ",'" + txt_name.Text + "','" + txt_address.Text + "','" + txt_phone.Text + "','" + txt_email.Text + "'," +
            "'Female','" + txt_dob.Text + "','" + ddl_course.SelectedItem.Text + "','" + ddl_sem.SelectedItem.Text + "'," +
            "'" + txt_admno.Text + "','Pending')");
        obj.WriteData("insert into Login values('" + txt_uname.Text + "','" + txt_pwd.Text + "','Student')");
        obj.WriteData("insert into allocation values('" + lblfloor.Text + "','" + lblroomno.Text + "','" + lblbedno.Text + "','" + txt_admno.Text + "','" + System.DateTime.Now.Date.ToShortDateString() + "','" + txtfdate.Text + "','" + txttdate.Text + "','" + lblBedrent.Text + "','" + lbldays.Text + "','" + lblmonths.Text + "','" + txtamount.Text + "','" + txtadvance.Text + "','Allocated')");
        obj.WriteData("update beddetails set status='NOT AVAILABLE' where roomno='" + lblroomno.Text + "' and bedno='" + lblbedno.Text + "'");
        SentoMail();
        Response.Write(obj.MessageBox("Registration completed successfully"));

        Session["admno"] = txt_admno.Text;
        Session["name"] = txt_name.Text;
        Session["address"] = txt_address.Text;
        Session["gender"] = "Female";
        Session["dob"] = txt_dob.Text;
        Session["course"] = ddl_course.SelectedItem.Text;
        Session["sem"] = ddl_sem.SelectedItem.Text;
        Session["mobile"] = txt_phone.Text;
        Session["email"] = txt_email.Text;
        Session["uname"] = txt_uname.Text;
        Session["pwd"] = txt_pwd.Text;
        Session["fdate"] = txtfdate.Text;
        Session["tdate"] = txttdate.Text;
        Session["days"] = lbldays.Text;
        Session["month"] = lblmonths.Text;
        Session["amount"] = txtamount.Text;
        Session["advance"] = txtadvance.Text;

        Server.Transfer("Print_Stud.aspx");
    }
    protected void txt_phone_TextChanged(object sender, EventArgs e)
    {
        txt_pwd.Text = txt_phone.Text;
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail()
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = txt_email.Text;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = "USERNAME FOR LOGIN IS " + txt_uname.Text + " AND YOUR PASSWORD IS " + txt_pwd.Text;
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
    protected void txt_admno_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtfdate_TextChanged(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(txtfdate.Text);
        if (dtm < System.DateTime.Now.Date)
        {
            Response.Write(obj.MessageBox("INVLAID FROM DATE"));
            txtfdate.Text = "";
        }
    }
    protected void txttdate_TextChanged(object sender, EventArgs e)
    {
        DateTime sdate = Convert.ToDateTime(txtfdate.Text);
        DateTime edate = Convert.ToDateTime(txttdate.Text);
        if (edate < sdate)
        {
            Response.Write(obj.MessageBox("INVLAID TO DATE"));
            txttdate.Text = "";
            lbldays.Text = "";
            lblmonths.Text = "";
            txtamount.Text = "";
        }
        else
        {
            lbldays.Text = Convert.ToString((edate - sdate).TotalDays);
            lblmonths.Text = Convert.ToString(Convert.ToInt64(edate.Subtract(sdate).Days / (365.25 / 12)));
            txtamount.Text = Convert.ToString(Convert.ToDouble(lblmonths.Text) * Convert.ToDouble(lblBedrent.Text));
        }
    }
}