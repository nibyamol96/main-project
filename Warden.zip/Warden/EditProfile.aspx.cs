﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class EditProfile : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    public static string ID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.ReadData("select * from employee where uname='" + (String)Session["uname"] + "'");
            if (obj.dr.Read())
            {
                txtdob.Text = obj.dr["dob"].ToString();
                txtfname.Text = obj.dr["fname"].ToString();
                txthname.Text = obj.dr["hname"].ToString();
                txtlname.Text = obj.dr["lname"].ToString();
                txtloc.Text = obj.dr["location"].ToString();
                txtmail.Text = obj.dr["email"].ToString();
                txtmob.Text = obj.dr["mobile"].ToString();
                txtpin.Text = obj.dr["pin"].ToString();
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (FileUpload1.HasFile)
        {
            string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
            if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPG" || ext == ".JPEG" || ext == ".PNG")
            {
                FileUpload1.SaveAs(Server.MapPath("~/Photo/" + FileUpload1.FileName));
                obj.WriteData("update employee set dob='" + txtdob.Text + "',fname='" + txtfname.Text + "',lname='" + txtlname.Text + "',hname='" + txthname.Text + "',location='" + txtloc.Text + "',email='" + txtmail.Text + "',mobile='" + txtmob.Text + "',photo='" + FileUpload1.FileName + "' where uname='" + (String)Session["uname"] + "'");
                Response.Write("<script>alert('Profile updated successfully')</script>");
                Server.Transfer("ViewProfile.aspx");
            }
            else
            {
                Response.Write("<script>alert('invalid extension')</script>");
            }
        }
        else
        {
            obj.WriteData("update employee set dob='" + txtdob.Text + "',fname='" + txtfname.Text + "',lname='" + txtlname.Text + "',hname='" + txthname.Text + "',location='" + txtloc.Text + "',email='" + txtmail.Text + "',mobile='" + txtmob.Text + "' where uname='" + (String)Session["uname"] + "'");
            Response.Write("<script>alert('Profile updated successfully')</script>");
            Server.Transfer("ViewProfile.aspx");
        }
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail()
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = txtmail.Text;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = "";
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("ViewProfile.aspx");
    }
    protected void txtdob_TextChanged(object sender, EventArgs e)
    {
        if (txtdob.Text != "")
        {
            DateTime yr = Convert.ToDateTime(txtdob.Text);
            double y = yr.Year;
            double cr = System.DateTime.Now.Year;
            double diff = cr - y;
            if (diff < 18 || diff > 50)
            {
                Response.Write("<script>alert('invalid date')</script>");
            }
        }
    }
    protected void txtmob_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtjdate_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void ddldesig_SelectedIndexChanged(object sender, EventArgs e)
    {
         
    }
}