﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Staff_ViewStudentAttendance : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select * from attendance,student where attendance.admno=student.admno and attendance.atdate='" + TextBox1.Text + "'", GridView1);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(TextBox1.Text);
        obj.FillGrid("select * from attendance,student where attendance.admno=student.admno and month(attendance.atdate)='" + dtm.Month + "'", GridView1);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(TextBox1.Text);
        obj.FillGrid("select * from attendance,student where attendance.admno=student.admno and year(attendance.atdate)='" + dtm.Year + "'", GridView1);
    }
}