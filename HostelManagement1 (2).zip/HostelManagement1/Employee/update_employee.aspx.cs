﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement1.Employee
{

    public partial class update_employee : System.Web.UI.Page
    {
        updation uobj = new updation();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["employee"] == null)
            {
                Response.Redirect("~/Employee/Employeehome.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["employee"].ToString();

                Loaddata();
            }
        }

        public void Loaddata()
        {
            DataTable dtReg = new DataTable();
            uobj.Emp_email= Session["employee"].ToString();
            dtReg = uobj.disply();
            if (dtReg.Rows.Count > 0)
            {

                if (dtReg.Rows[0]["employee_gender"].ToString() == "male")
                {
                    rdbempmale.Checked = true;

                }
                else
                {
                    rdbempfemale.Checked = true;
                }
                txtempid.Text=Convert.ToString(dtReg.Rows[0]["employee_id"]);
                txtupdateempname.Text = Convert.ToString(dtReg.Rows[0]["employee_name"]);
                txtupdateempaddress.Text = Convert.ToString(dtReg.Rows[0]["employee_address"]);
                txtupdateempage.Text = Convert.ToString(dtReg.Rows[0]["employee_age"]);
                txtupdateempmobile.Text = Convert.ToString(dtReg.Rows[0]["employee_mobile"]);
                txtupdateemail.Text = Convert.ToString(dtReg.Rows[0]["employee_email"]);
                dpdupdateempcountry.Text = Convert.ToString(dtReg.Rows[0]["employee_country"]);
                dpdupdateempstate.Text = Convert.ToString(dtReg.Rows[0]["employee_state"]);
                dpdupdateempdistrict.Text = Convert.ToString(dtReg.Rows[0]["employee_district"]);
                dpdupdateempempcategory.Text = Convert.ToString(dtReg.Rows[0]["employee_category"]);
                
            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            uobj.Emp_email = Session["employee"].ToString();
            uobj.Emp_name = txtupdateempname.Text;
            uobj.Emp_address = txtupdateempaddress.Text;
            uobj.Emp_age = txtupdateempage.Text;
            uobj.Emp_mobile = txtupdateempmobile.Text;
            uobj.Emp_email = txtupdateemail.Text;
            uobj.Emp_country = dpdupdateempcountry.Text;
            uobj.Emp_state = dpdupdateempstate.Text;
            uobj.Emp_district = dpdupdateempdistrict.Text;
            uobj.Emp_category = dpdupdateempempcategory.Text;
            uobj.update();
            Response.Write("<script>alert('Profile updated successfully')</script>");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //txtempid.Enabled = true;
            txtupdateempname.Enabled = true;
            txtupdateempaddress.Enabled = true;
            txtupdateempage.Enabled = true;
            txtupdateempmobile.Enabled = true;
            dpdupdateempcountry.Enabled = true;
            dpdupdateempstate.Enabled = true;
            dpdupdateempdistrict.Enabled = true;
            dpdupdateempempcategory.Enabled = true;
            btnupdateemployee.Visible= true;
            btncancel.Visible = true;
            Button1.Visible = false;
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Employee/update_employee");
        }
    }
}