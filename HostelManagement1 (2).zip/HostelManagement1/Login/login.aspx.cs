﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HostelManagement1.Class;

namespace HostelManagement1.Login
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        login objlogn = new login();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        

        protected void btnlogsubmit_Click(object sender, EventArgs e)
        {
            
            DataTable dtReg = new DataTable();
            objlogn.Username = txtlogusername.Text;
            objlogn.Password = txtlogpassword.Text;
            dtReg = objlogn.loginfn();
            if (objlogn.Username == "admin" && objlogn.Password == "admin")
            {
                Session["Admin"] = txtlogusername.Text;
                Response.Redirect("~/Admin/adminhome.aspx");
            }
            else if (dtReg.Rows.Count > 0)
            {
                objlogn.Loginid = Convert.ToInt16(dtReg.Rows[0]["login_id"].ToString());
                objlogn.Usertype = dtReg.Rows[0]["user_type"].ToString();

                if (objlogn.Usertype == "Employee")
                {
                    Session["employee"] = txtlogusername.Text;
                    Session["employee_id"] = Convert.ToString(dtReg.Rows[0][0]);
                    Response.Redirect("~/Employee/employee.aspx");
                }
                else if (objlogn.Usertype == "Student")
                {
                    Session["student"] = txtlogusername.Text;
                    //Session["student_id"] = Convert.ToString(dtReg.Rows[0]["student_id"]);
                    Response.Redirect("~/Student/studenthome.aspx");
                }
            }

            else if (objlogn.Username == "assistantwarden" && objlogn.Password == "assistantwarden")
            {
                Response.Redirect("~/AssistantWarden/assiatantwarden_home.aspx");
            }

            else
            {
                Response.Write("<script>alert('Invalid username or password')</script>");
            }
          
        }

        protected void btnlogcancel_Click(object sender, EventArgs e)
        {

        }

        protected void btnlogcancel_Click1(object sender, EventArgs e)
        {
            Response.Redirect("~/Login/login");
        }
    }
}