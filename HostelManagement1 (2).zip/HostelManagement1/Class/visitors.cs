﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;


namespace HostelManagement1.Class
{
    public class visitors
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        

        private string visitor_name;
        private string visitor_phone;
        private string student_name;
        private string relation;
        private string visiting_date;
        private string entry_time;
        private string leaving_time;
        private string purpose;

        public string Visitor_name { get => visitor_name; set => visitor_name = value; }
        public string Visitor_phone { get => visitor_phone; set => visitor_phone = value; }
        public string Student_name { get => student_name; set => student_name = value; }
        public string Relation { get => relation; set => relation = value; }
        public string Visiting_date { get => visiting_date; set => visiting_date = value; }
        public string Entry_time { get => entry_time; set => entry_time = value; }
        public string Leaving_time { get => leaving_time; set => leaving_time = value; }
        public string Purpose { get => purpose; set => purpose = value; }

        public void addvisitor()
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand("Select max(visitor_id) from visitors ", con);
            int visitorid;
            object cMax= cmd.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                visitorid = (int)cMax;
                visitorid++;
            }
            else
            {
                visitorid = 1;
            }
            string qry = "insert into visitors values('" + visitorid + "', @visitor_name, @visitor_phone,@student_name,@relation,@visiting_date,@entry_time,@leaving_time,@purpose)";
            SqlCommand cmd1 = new SqlCommand(qry, con);
            cmd1.Parameters.AddWithValue("@visitor_name", visitor_name);
            cmd1.Parameters.AddWithValue("@visitor_phone", visitor_phone);
            cmd1.Parameters.AddWithValue("@student_name", student_name);
            cmd1.Parameters.AddWithValue("@relation", relation);
            cmd1.Parameters.AddWithValue("@visiting_date", visiting_date);
            cmd1.Parameters.AddWithValue("@entry_time", entry_time);
            cmd1.Parameters.AddWithValue("@leaving_time", leaving_time);
            cmd1.Parameters.AddWithValue("@purpose", purpose);
            cmd1.ExecuteNonQuery();
        }
    }
}