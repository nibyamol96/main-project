﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HostelManagement1.Class;



namespace HostelManagement1.Class
{
    public class updation
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }


        private string emp_id;
        private string emp_email;
        private string emp_name;
        private string emp_address;
        private string emp_gender;
        private string emp_age;
        private string emp_mobile;
        private string emp_country;
        private string emp_state;
        private string emp_district;
        private string emp_category;
        private string emp_photo;
        public string Emp_email { get => emp_email; set => emp_email = value; }
        public string Emp_name { get => emp_name; set => emp_name = value; }
        public string Emp_address { get => emp_address; set => emp_address = value; }
        public string Emp_age { get => emp_age; set => emp_age = value; }
        public string Emp_mobile { get => emp_mobile; set => emp_mobile = value; }
        public string Emp_country { get => emp_country; set => emp_country = value; }
        public string Emp_state { get => emp_state; set => emp_state = value; }
        public string Emp_district { get => emp_district; set => emp_district = value; }
        public string Emp_category { get => emp_category; set => emp_category = value; }
        public string Emp_photo { get => emp_photo; set => emp_photo = value; }
        public string Emp_id { get => emp_id; set => emp_id = value; }
        public string Emp_gender { get => emp_gender; set => emp_gender = value; }
        public string Updatefname { get => updatefname; set => updatefname = value; }
        public string Updatelname { get => updatelname; set => updatelname = value; }
        public string Updateaddress { get => updateaddress; set => updateaddress = value; }
        public string Updatedateofbirth { get => updatedateofbirth; set => updatedateofbirth = value; }
        public string Upadatemobile { get => upadatemobile; set => upadatemobile = value; }
        public string Updatecountry { get => updatecountry; set => updatecountry = value; }
        public string Updatestate { get => updatestate; set => updatestate = value; }
        public string Updtedistrict { get => updtedistrict; set => updtedistrict = value; }
        public string Updateemail { get => updateemail; set => updateemail = value; }
        public string Upadateguardianname { get => upadateguardianname; set => upadateguardianname = value; }
        public string Updateguardianaddress { get => updateguardianaddress; set => updateguardianaddress = value; }
        public string Updategurdianmobile { get => updategurdianmobile; set => updategurdianmobile = value; }
        
        public string Updatephoto { get => updatephoto; set => updatephoto = value; }
        public string Roomtype { get => roomtype; set => roomtype = value; }

        public DataTable ExecuteSelectQueries()
        {
            OpenConection();

            String qry = "select * from employee_registration ";
           
            SqlCommand cmd = new SqlCommand(qry, con);
           
            cmd.ExecuteNonQuery();
            
            DataTable dtReg = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
           
            
            return dtReg;

        }

        public DataTable disply()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from employee_registration where employee_email=@e_email";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@e_email", Emp_email);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;

        }
        public void update()
        {

            OpenConection();

            
            String qry1 = "update employee_registration set employee_name=@emp_name,employee_age=@emp_age,employee_mobile=@emp_mobile,employee_email=@emp_email,"
            + "employee_country=@emp_country,employee_state=@emp_state,employee_district=@emp_district,"
            + "employee_category=@emp_category,employee_address=@emp_address where employee_email=@emp_email ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);
           
            //cmd1.Parameters.AddWithValue("@emp_id", Emp_id);

            cmd1.Parameters.AddWithValue("@emp_name", Emp_name);
            cmd1.Parameters.AddWithValue("@emp_age", Emp_age);
            cmd1.Parameters.AddWithValue("@emp_mobile", Emp_mobile);
            cmd1.Parameters.AddWithValue("@emp_email", Emp_email);

            cmd1.Parameters.AddWithValue("@emp_country", Emp_country);
            cmd1.Parameters.AddWithValue("@emp_state", Emp_state);
            cmd1.Parameters.AddWithValue("@emp_district", Emp_district);

            cmd1.Parameters.AddWithValue("@emp_category", Emp_category);
            cmd1.Parameters.AddWithValue("@emp_address", emp_address);



            cmd1.ExecuteNonQuery();



        }



        //-----------------------------Student updation----------------------------//

        private string updatefname;
        private string updatelname;
        private string updateaddress;
        private string updatedateofbirth;
        private string upadatemobile;
        private string updatecountry;
        private string updatestate;
        private string updtedistrict;
        private string updateemail;
        private string upadateguardianname;
        private string updateguardianaddress;
        private string updategurdianmobile;
        private string roomtype;
        private string updatephoto;

        public DataTable ExecuteSelectQueriess()
        {
            OpenConection();

            string qry1 = "select * from student_registration";
            
            SqlCommand cmd1 = new SqlCommand(qry1, con);
            
            cmd1.ExecuteNonQuery();
            
            DataTable dtReg1 = new DataTable();
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            da1.Fill(dtReg1);
            return dtReg1;
           

        }
        public DataTable disply1()
        {
            DataTable dtReg = new DataTable();
            OpenConection();

            String qry = "select * from student_registration where email_id = @stud_email";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@stud_email", Updateemail);
            cmd.ExecuteNonQuery();
            CloseConnection();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);

            CloseConnection();
            return dtReg;

        }
        public void studentupdate()
        {

            OpenConection();


            String qry1 = "update student_registration set first_name=@stud_fname,last_name=@stud_lname,address=@stud_address,"
            + "date_of_birth=@stud_dob,mobile=@stud_mobile,country=@stud_country,state=@stud_state,city=@stud_district,"
            + "guardean_name=@stud_guardianname,guardean_address=@stud_guardianaddress,guardean_mobile=@stud_guardianmobile,room_type= @stud_roomtype where email_id=@stud_email ";

            SqlCommand cmd1 = new SqlCommand(qry1, con);

            //cmd1.Parameters.AddWithValue("@emp_id", Emp_id);

            cmd1.Parameters.AddWithValue("@stud_fname", Updatefname);
            cmd1.Parameters.AddWithValue("@stud_lname", Updatelname);
            cmd1.Parameters.AddWithValue("@stud_address", Updateaddress);
            cmd1.Parameters.AddWithValue("@stud_dob", Updatedateofbirth);
            cmd1.Parameters.AddWithValue("@stud_mobile", Upadatemobile);
            cmd1.Parameters.AddWithValue("@stud_email", Updateemail);
            cmd1.Parameters.AddWithValue("@stud_country", Updatecountry);
            cmd1.Parameters.AddWithValue("@stud_state", Updatestate);
            cmd1.Parameters.AddWithValue("@stud_district", Updtedistrict);
            cmd1.Parameters.AddWithValue("@stud_guardianname", upadateguardianname);
            cmd1.Parameters.AddWithValue("@stud_guardianaddress", Updateguardianaddress);
            cmd1.Parameters.AddWithValue("@stud_guardianmobile", Updategurdianmobile);
            cmd1.Parameters.AddWithValue("@stud_roomtype", Roomtype);
            cmd1.ExecuteNonQuery();



        }

    }
}