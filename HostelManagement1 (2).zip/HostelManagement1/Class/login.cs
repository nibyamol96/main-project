﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
namespace HostelManagement1.Class
{
    public class login
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }
        private string username;
        private string password;
        private string usertype;
        private int loginid;
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Usertype { get => usertype; set => usertype = value; }
        public int Loginid { get => loginid; set => loginid = value; }

        public DataTable loginfn()
        {
            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand("Select login_id,user_type from login where username=@username and password=@password", con);
            //command.Parameters.AddWithValue("@username", username);
            //command.Parameters.AddWithValue("@password", password);
            if (String.IsNullOrEmpty(username))
            {
                command.Parameters.AddWithValue("@username", DBNull.Value);
            }
            else
                command.Parameters.AddWithValue("@username", username);

            if (String.IsNullOrEmpty(password))
            {
                command.Parameters.AddWithValue("@password", DBNull.Value);
            }
            else
                command.Parameters.AddWithValue("@password", password);


            command.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;  
        }

    }

}