﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement1.Class
{
    public class complaint
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        private string email;
        private int rno;
        private string fdb;
        private string status;
        public int Rno { get => rno; set => rno = value; }
        public string Fdb { get => fdb; set => fdb = value; }
        public string Status { get => status; set => status = value; }
        public string Email { get => email; set => email = value; }

        public void insertcomplaint()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(f_id) from complaintandsuggestion ", con);
            int f_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                f_id = (int)cMax;
                f_id++;
            }
            else
            {
                f_id = 1;
            }
            string qry1 = "select student_id from student_registration where email_id=@email";
            SqlCommand rno = new SqlCommand(qry1, con);
            string qry = "insert into complaintandsuggestion values (" + f_id + ",@rno,GETDATE(),@feedback,@status)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@rno", Rno);
            cmd.Parameters.AddWithValue("@feedback", Fdb);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.ExecuteNonQuery();
        }
    }
}