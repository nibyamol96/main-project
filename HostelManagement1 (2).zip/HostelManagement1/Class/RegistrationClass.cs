﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement1.Class
{
    public class RegistrationClass
    {

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        //-------------STUDENT REGISTRATION-----------




        private string fname;
        private string lname;
        private  string address;
        private string mob;
        private DateTime dob;
        private string city;
        private string state;
        private string country;
        private string guardeanname;
        private string guardeanaddress;
        private string gmob;
        private string roomtype;
        private string email;
        private string photo;
        private string username;
        private string password;
        private string usertype;

        public string Fname { get => fname; set => fname = value; }
        public string Lname { get => lname; set => lname = value; }
        public string Address { get => address; set => address = value; }
        public string Mob { get => mob; set => mob = value; }
        public DateTime Dob { get => dob; set => dob = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public string Country { get => country; set => country = value; }
        public string Guardeanname { get => guardeanname; set => guardeanname = value; }
        public string Guardeanaddress { get => guardeanaddress; set => guardeanaddress = value; }
        public string Gmob { get => gmob; set => gmob = value; }
        public string Roomtype { get => roomtype; set => roomtype = value; }
        public string Email { get => email; set => email = value; }
        public string Photo { get => photo; set => photo = value; }
        public string Empname { get => empname; set => empname = value; }
        public string Empaddress { get => empaddress; set => empaddress = value; }
        public string Empgender { get => empgender; set => empgender = value; }
        public string Empage { get => empage; set => empage = value; }
        public string Empmobile { get => empmobile; set => empmobile = value; }
        public string Empcountry { get => empcountry; set => empcountry = value; }
        public string Empstate { get => empstate; set => empstate = value; }
        public string Empdistrict { get => empdistrict; set => empdistrict = value; }
        public string Empcategory { get => empcategory; set => empcategory = value; }
        public string Empphoto { get => empphoto; set => empphoto = value; }
        public string Empemail { get => empemail; set => empemail = value; }
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public string Usertype { get => usertype; set => usertype = value; }

        public void Registration()
        {
            OpenConection();
           /* SqlCommand command = new SqlCommand("Select max(student_id) from student_registration ", con);
            int student_id;
            object cMax = command.ExecuteScalar();
            if(cMax !=DBNull.Value)
            {
                student_id = (int)cMax;
                student_id++;
            }
            else
            {
                student_id = 1;
            }*/
            SqlCommand cmd1 = new SqlCommand("Select login_id from login where username='" + username + "' and password='" + password + "' ", con);
            int log_id;
            object loginid = cmd1.ExecuteScalar();
            if (loginid != DBNull.Value)
            {
                log_id = (int)loginid;
            }
            else
            {
                log_id = 0;
            }
            string qry = "insert into student_registration(first_name,last_name,address,mobile,date_of_birth,"+
                "city,state,country,guardean_name,guardean_address,guardean_mobile,room_type,email_id,photo,login_id) " +
                "values( @fname, @lname,@address,@mobile,@dateofbirth,@city,@state,@country,@guardeanname,"+
                "@guardeanaddress,@guardeanmobile,@roomtype,@email,@photo,'"+log_id+"')"; 
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@fname", fname);
            cmd.Parameters.AddWithValue("@lname", lname);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@mobile", mob);
            cmd.Parameters.AddWithValue("@dateofbirth", dob);
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@state", state);
            cmd.Parameters.AddWithValue("@country", country);
            cmd.Parameters.AddWithValue("@guardeanname", guardeanname);
            cmd.Parameters.AddWithValue("@guardeanaddress", guardeanaddress);
            cmd.Parameters.AddWithValue("@guardeanmobile", gmob);
            cmd.Parameters.AddWithValue("@roomtype", roomtype);
            cmd.Parameters.AddWithValue("@email", email);
            cmd.Parameters.AddWithValue("@photo", photo);
            cmd.ExecuteNonQuery();

        }

        //--------EMPLOYE REGISTRATION--------


        private string empname;
        private string empaddress;
        private string empgender;
        private string empage;
        private string empemail;
        private string empmobile;
        private string empcountry;
        private string empstate;
        private string empdistrict;
        private string empcategory;
        private string empphoto;



        public string GetUsername()
        {
            OpenConection();
            string qry = "select employee_email from employee_registration where employee_email=@empemail;";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@empemail", Empemail);
            string typ = "";
            Object obj = cmd.ExecuteScalar();
            if (obj != DBNull.Value)
            {
                typ = (string)obj;
            }
            CloseConnection();
            return typ;

        }

        public void employee_registration()
        {
            OpenConection();
            /*SqlCommand command = new SqlCommand("Select max(employee_id) from employee_registration ", con);
            int employee_id;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                employee_id = (int)cMax;
                employee_id++;
            }
            else
            {
                employee_id = 1;
            }*/
            SqlCommand cmd1 = new SqlCommand("Select login_id from login where username='"+username+ "' and password='"+password+"' ", con);
            int log_id;
            object loginid = cmd1.ExecuteScalar();
            if (loginid != DBNull.Value)
            {
                log_id = (int)loginid;
            }
            else
            {
                log_id = 0;
            }
            string qry = "insert into employee_registration(employee_name,employee_gender,employee_age,employee_mobile," +
                "employee_email,employee_country,employee_state,employee_district,employee_category,employee_address,employee_photo,login_id) " +
                "values(@empname,@empgender,@empage,@empmobile,@empemail,@empcountry,@empstate," +
                "@empdistrict,@empcategory,@empaddress,@empphoto,'"+log_id+"')";
            SqlCommand cmd = new SqlCommand(qry, con);
            
            cmd.Parameters.AddWithValue("@empname", empname);
            cmd.Parameters.AddWithValue("@empgender", empgender);
            cmd.Parameters.AddWithValue("@empage", empage);
            cmd.Parameters.AddWithValue("@empmobile", empmobile);
            cmd.Parameters.AddWithValue("@empcountry", empcountry);
            cmd.Parameters.AddWithValue("@empstate", empstate);
            cmd.Parameters.AddWithValue("@empdistrict", empdistrict);
            cmd.Parameters.AddWithValue("@empcategory", empcategory);
            cmd.Parameters.AddWithValue("@empaddress", empaddress);
            cmd.Parameters.AddWithValue("@empemail", Empemail);
            cmd.Parameters.AddWithValue("@empphoto", empphoto);
            
            cmd.ExecuteNonQuery();
            CloseConnection();

        }
        public void InsertLogin()
        {
            OpenConection();
            string qry = "insert into login values(@uname,@pswd,@utype)";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@uname", username);
            cmd.Parameters.AddWithValue("@pswd", password);
            cmd.Parameters.AddWithValue("@utype", usertype);
            cmd.ExecuteNonQuery();
            CloseConnection();
        }
    }
    
}
