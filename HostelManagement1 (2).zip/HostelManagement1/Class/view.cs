﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using HostelManagement1.Class;



namespace HostelManagement1.Class
{
    public class view
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }
        private int student_id;

        public int Student_id { get => student_id; set => student_id = value; }
        public DataTable ExecuteSelectQueries()
        {

            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand(" Select student_id,photo,first_name,last_name,address,date_of_birth,mobile,email_id,country,state,city,guardean_name,guardean_address,guardean_mobile,room_type from student_registration ", con);

            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable

            da.Fill(dtReg);
            CloseConnection();
            return dtReg;


        }
        public DataTable ExecuteSelectQueriess()
        {

            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand(" Select employee_id,employee_name,employee_gender,employee_age,employee_mobile,employee_email,employee_country,employee_state,employee_district,employee_category,employee_address,employee_photo from employee_registration ", con);

            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable

            da.Fill(dtReg);
            CloseConnection();
            return dtReg;


        }
        public DataTable ExecuteSelectQueriesss()
        {

            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand(" Select visitor_id,visitor_name,phone,student_name,relation,visiting_date,entry_time,leaving_time,visiting_purpose from visitors", con);

            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable

            da.Fill(dtReg);
            CloseConnection();
            return dtReg;


        }


    }
}
