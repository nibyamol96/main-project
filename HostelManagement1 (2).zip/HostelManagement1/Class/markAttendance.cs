﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HostelManagement1.Class
{
    public class markAttendance
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;
        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        private string ab;
        public SqlDataAdapter da = new SqlDataAdapter();
        public SqlDataReader dr;
        public DataTable dt = new DataTable();

        public DataTable ExecuteSelectQueries()
        {
            //  SqlCommand command = new SqlCommand("Select * from S_Registration where name=@zip", conn);
            //   command.Parameters.AddWithValue("@zip", "india");
            OpenConection();
            DataTable dtReg = new DataTable();
            SqlCommand command = new SqlCommand("Select student_id,first_name,last_name from student_registration ", con);
            //SqlCommand command1=new SqlCommand("Select * from memreg ", con");
         
            OpenConection();
            SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable

            da.Fill(dtReg);
            CloseConnection();
            return dtReg;
        }
        //public DataTable ExecuteSelectQueries1()
        //{
        //    OpenConection();
        //    DataTable dtReg = new DataTable();
        //    SqlCommand command = new SqlCommand("Select * from  ", con);

        //    SqlDataAdapter da = new SqlDataAdapter(command);// this will query your database and return the result to your datatable
        //    da.Fill(dtReg);
        //    CloseConnection();
        //    return dtReg;
        //}

        private int abc;
        private int ron;
        private int student_id;

        public int Ron { get => ron; set => ron = value; }
        public string Ab { get => ab; set => ab = value; }
        public int Abc { get => abc; set => abc = value; }
        public int Student_id { get => student_id; set => student_id = value; }
        public SqlCommand cmd { get; private set; }

        public void MarkAbsent()
        {
            OpenConection();
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(attendence_id) from attendence ", con);
            int att_id = 0;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                att_id = (int)cMax;
                att_id++;
            }
            else
            {
                att_id = 1;
            }

            string qry = "insert into attendence values (" + att_id + ",@student_id,GETDATE())";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@student_id", student_id);
            cmd.ExecuteNonQuery();
        }
        public void WriteData(string sql)
        {
            OpenConection();
            cmd = new SqlCommand(sql, con);
            cmd.ExecuteNonQuery();
        }
        public void ReadData(string sql)
        {
            OpenConection();
            cmd = new SqlCommand(sql, con);
            dr = cmd.ExecuteReader();
        }
        public void adapter(string sql)
        {
            OpenConection();
            cmd = new SqlCommand(sql, con);
            da.SelectCommand = cmd;
            da.Fill(dt);
        }
        public void FillGrid(string sql, System.Web.UI.WebControls.GridView grdvw)
        {
            adapter(sql);
            if (dt.Rows.Count > 0)
            {
                grdvw.DataSource = dt;
                grdvw.DataBind();
            }
        }
       
        public string MessageBox(string msg)
        {
            string Message = "<script>alert('" + msg + "')</script>";
            return Message;
        }
    }
    }