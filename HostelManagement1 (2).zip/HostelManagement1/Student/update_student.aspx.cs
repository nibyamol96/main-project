﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;

namespace HostelManagement1.Student
{
    public partial class update_student : System.Web.UI.Page
    {
        updation studuobj = new updation();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["student"] == null)
            {
                Response.Redirect("~/Student/studenthome.aspx");
            }

            if (!IsPostBack)
            {
                string Uid = Session["student"].ToString();

                Loaddata();
            }
        }
        public void Loaddata()
        {
            DataTable dtReg1 = new DataTable();
            studuobj.Updateemail = Session["student"].ToString();
            dtReg1 = studuobj.disply1();
            if (dtReg1.Rows.Count > 0)
            {

               
                txtepdatefname.Text = Convert.ToString(dtReg1.Rows[0]["first_name"]);
                txtupdatelname.Text = Convert.ToString(dtReg1.Rows[0]["last_name"]);
                txtupdateaddress.Text = Convert.ToString(dtReg1.Rows[0]["address"]);
                txtupdatedateofbirth.Text = Convert.ToString(dtReg1.Rows[0]["date_of_birth"]);
                txtupdatemobile.Text = Convert.ToString(dtReg1.Rows[0]["mobile"]);
                txtupdatecountry.Text = Convert.ToString(dtReg1.Rows[0]["country"]);
                txtupdatestate.Text = Convert.ToString(dtReg1.Rows[0]["state"]);
                txtupdatedistrict.Text = Convert.ToString(dtReg1.Rows[0]["city"]);
                txtupdatetemail.Text = Convert.ToString(dtReg1.Rows[0]["email_id"]);
                txtupdateguardeanname.Text = Convert.ToString(dtReg1.Rows[0]["guardean_name"]);
                txtupdateguardeanaddress.Text = Convert.ToString(dtReg1.Rows[0]["guardean_address"]);
               txtupdateguardeanmobile.Text = Convert.ToString(dtReg1.Rows[0]["guardean_mobile"]);
                dropdownupdateroomtype.Text = Convert.ToString(dtReg1.Rows[0]["room_type"]);
                

            }
        }

        protected void btnupdateedit_Click(object sender, EventArgs e)
        {
            txtepdatefname.Enabled = true;
            txtupdatelname.Enabled = true;
            txtupdateaddress.Enabled = true;
            txtupdatedateofbirth.Enabled = true;
            txtupdatemobile.Enabled = true;
            txtupdatecountry.Enabled = true;
            txtupdatestate.Enabled = true;
            txtupdatedistrict.Enabled = true;
            txtupdateguardeanname.Enabled = true;
            txtupdateguardeanaddress.Enabled = true;
            txtupdateguardeanmobile.Enabled = true;
            dropdownupdateroomtype.Enabled = true;
            btnupdate.Visible = true;
            btncancel.Visible = true;
            btnupdateedit.Visible = false;
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            studuobj.Updateemail = Session["student"].ToString();
            studuobj.Updatefname = txtepdatefname.Text;
            studuobj.Updatelname = txtupdatelname.Text;
            studuobj.Updateaddress = txtupdateaddress.Text;
            studuobj.Upadatemobile = txtupdateguardeanmobile.Text;
            studuobj.Updatedateofbirth = txtupdatedateofbirth.Text;
            studuobj.Updatecountry = txtupdatecountry.Text;
            studuobj.Updatestate = txtupdatestate.Text;
            studuobj.Updtedistrict = txtupdatedistrict.Text;
            studuobj.Updateemail = txtupdatetemail.Text;
            studuobj.Upadateguardianname = txtupdateguardeanname.Text;
            studuobj.Updateguardianaddress = txtupdateguardeanaddress.Text;
            studuobj.Updategurdianmobile = txtupdateguardeanmobile.Text;
            studuobj.Roomtype = dropdownupdateroomtype.Text;
            studuobj.studentupdate();
            Response.Write("<script>alert('Profile updated successfully')</script>");
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Student/studenthome");
        }
    }
}