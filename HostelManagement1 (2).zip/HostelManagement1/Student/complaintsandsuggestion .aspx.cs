﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
namespace HostelManagement1.Student
{
    public partial class complaintsandsuggestion : System.Web.UI.Page
    {
        complaint comobj = new complaint();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            comobj.Fdb =txtcomplaint.Text;
            comobj.Email = Session["student"].ToString();
            comobj.insertcomplaint();
           // lbmsg3.Text = "Send Feed Back";
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    comobj.User_id = Convert.ToInt32(Session["student"]);
        //    comobj.Complaintandsuggession = txtcomplaint.Text;
        //    //comobj.Status = "Not Read";
        //    comobj.Complaint_id = comobj.insertcomplaint();

        //   // comobj.Status = "1";
        //   // comobj.sendstatus()
        //}

        //protected void Button2_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("~/Student/complaintandsuggestion.aspx");

        //}
    }
}