﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace HostelManagement1.Admin
{
    public partial class Employee_Register : System.Web.UI.Page
    {
        RegistrationClass robj = new RegistrationClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            robj.Empemail = txtemail.Text;
            string utyp = "";
            utyp = robj.GetUsername();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exist')</script>");
            }
            else
            {

                if (rdbempfemale.Checked)
                {
                    robj.Empgender = rdbempfemale.Text;
                }
                else
                {
                    robj.Empgender = rdbempmale.Text;
                }
                robj.Empname = txtempname.Text;
                robj.Empaddress = txtempaddress.Text;
                robj.Empage = txtempage.Text;
                robj.Empmobile = txtempmobile.Text;
                robj.Empemail = txtemail.Text;
                robj.Empcountry = dpdempcountry.SelectedItem.Text;
                robj.Empstate = dpdempstate.SelectedItem.Text;
                robj.Empdistrict = dpdempdistrict.SelectedItem.Text;
                robj.Empcategory = dpdempempcategory.SelectedItem.Text;
                string filename = Path.GetFileName(empphoto.PostedFile.FileName);
                string ext = Path.GetExtension(filename);
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
                {
                    string src = Server.MapPath("~/Photo") + "\\" + txtempname.Text + ".JPG";
                    empphoto.PostedFile.SaveAs(src);
                    string picpath = "~/Photo/" + txtempname.Text + ".JPG";
                    robj.Empphoto = picpath;
                }
                robj.Username = txtemail.Text.ToString();
                robj.Password = txtempmobile.Text.ToString();
                robj.Usertype = "Employee";
                robj.InsertLogin();
                robj.employee_registration();
                Response.Write("<script>alert(' successfully registered')</script>");
            }

        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/Employee_Register");
        }
    }
}