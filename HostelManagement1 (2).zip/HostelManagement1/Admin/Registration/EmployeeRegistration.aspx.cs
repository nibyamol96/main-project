﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;
namespace HostelManagement1.Registration
{
    public partial class EmployeeRegistration : System.Web.UI.Page
    {
        RegistrationClass empobj = new RegistrationClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            empobj.Empemail = txtemail.Text;
            string utyp = "";
            utyp = empobj.GetUsername();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exist')</script>");
            }
            else
            {

                if (rdbempfemale.Checked)
                {
                    empobj.Empgender = rdbempfemale.Text;
                }
                else
                {
                    empobj.Empgender = rdbempmale.Text;
                }
                empobj.Empname = txtempname.Text;
                empobj.Empaddress = txtempaddress.Text;
                empobj.Empage = txtempage.Text;
                empobj.Empmobile = txtempmobile.Text;
                empobj.Empemail = txtemail.Text;
                empobj.Empcountry = dpdempcountry.SelectedItem.Text;
                empobj.Empstate = dpdempstate.SelectedItem.Text;
                empobj.Empdistrict = dpdempdistrict.SelectedItem.Text;
                empobj.Empcategory = dpdempempcategory.SelectedItem.Text;
                string filename = Path.GetFileName(empphoto.PostedFile.FileName);
                string ext = Path.GetExtension(filename);
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
                {
                    string src = Server.MapPath("~/Photo") + "\\" + txtempname.Text + ".JPG";
                    empphoto.PostedFile.SaveAs(src);
                    string picpath = "~/Photo/" + txtempname.Text + ".JPG";
                    empobj.Empphoto = picpath;
                }
                empobj.Username = txtemail.Text.ToString();
                empobj.Password = txtempmobile.Text.ToString();
                empobj.Usertype = "Employee";
                empobj.InsertLogin();
                empobj.employee_registration();
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/Registration/EmployeeRegistration");
        }
    }
}