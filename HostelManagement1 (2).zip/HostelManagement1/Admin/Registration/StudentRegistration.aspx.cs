﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;
namespace HostelManagement1.Registration
{
    public partial class StudentRegistration : System.Web.UI.Page
    {

        RegistrationClass robj = new RegistrationClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            robj.Empemail = txtemail.Text;
            string utyp = "";
            utyp = robj.GetUsername();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exist')</script>");
            }
            else
            {

                robj.Fname = txtfname.Text;
                robj.Lname = txtlname.Text;
                robj.Address = txtaddress.Text;
                robj.Dob = Convert.ToDateTime(txtdateofbirth.Text);
                robj.Mob = txtmobile.Text;
                robj.Country = txtcountry.Text;
                robj.State = txtstate.Text;
                robj.City = txtcity.Text;
                robj.Guardeanname = txtguardeanname.Text;
                robj.Guardeanaddress = txtguardeanaddress.Text;
                robj.Gmob = txtguardeanmobile.Text;
                robj.Roomtype = dropdownroomtype.SelectedItem.Text;
                robj.Email = txtemail.Text;
                string filename = Path.GetFileName(photo.PostedFile.FileName);
                string ext = Path.GetExtension(filename);
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
                {
                    string src = Server.MapPath("~/Photo") + "\\" + txtfname.Text + ".JPG";
                    photo.PostedFile.SaveAs(src);
                    string picpath = "~/Photo/" + txtfname.Text + ".JPG";
                    robj.Photo = picpath;
                }
                robj.Username = txtemail.Text.ToString();
                robj.Password = txtmobile.Text.ToString();
                robj.Usertype = "Student";
                robj.InsertLogin();
                robj.Registration();
            }
        }
        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin/Registration/StudentRegistration");
        }
    }
    }