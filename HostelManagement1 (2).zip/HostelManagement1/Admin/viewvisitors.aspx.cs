﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
namespace HostelManagement1.Admin
{
    public partial class viewvisitors : System.Web.UI.Page
    {
        HostelManagement1.Class.view vvobj = new HostelManagement1.Class.view();
        protected void Page_Load(object sender, EventArgs e)
        {
            loaddata();
        }
        private void loaddata()
        {
            DataTable dtReg = new DataTable();
            dtReg = vvobj.ExecuteSelectQueriesss();

            if (dtReg.Rows.Count > 0)
            {
                //viewstudents.DataSourceID= null;

                view_visitor.DataSource = dtReg;
                view_visitor.DataBind();
            }

        }

    }
}
