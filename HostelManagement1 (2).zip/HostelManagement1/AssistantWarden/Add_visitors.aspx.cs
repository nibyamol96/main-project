﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
namespace HostelManagement1.AssistantWarden
{
    public partial class Add_visitors : System.Web.UI.Page
    {
        visitors vobj = new visitors();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void btnvisitor_save_Click(object sender, EventArgs e)
        {
            vobj.Visitor_name = txtvisitor_name.Text;
            vobj.Visitor_phone = txtvisitor_phone.Text;
            vobj.Student_name = txtstudname.Text;
            vobj.Relation = txtrelation.Text;
            vobj.Visiting_date = txtvisiting_date.Text;
            vobj.Entry_time = txtentry_time.Text;
            vobj.Leaving_time = txtleaving_time.Text;
            vobj.Purpose = txtvisiting_purpose.Text;
            vobj.addvisitor();
        }
    }
}