﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HostelManagement1.Class;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace HostelManagement1.AssistantWarden
{
    public partial class StudentRegistration : System.Web.UI.Page
    {
        RegistrationClass studobj = new RegistrationClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            studobj.Empemail = txtemail.Text;
            string utyp = "";
            utyp = studobj.GetUsername();
            if (utyp != null)
            {

                Response.Write("<script>alert('username already exist')</script>");
            }
            else
            {

                studobj.Fname = txtfname.Text;
                studobj.Lname = txtlname.Text;
                studobj.Address = txtaddress.Text;
                studobj.Dob = Convert.ToDateTime(txtdateofbirth.Text);
                studobj.Mob = txtmobile.Text;
                studobj.Country = txtcountry.Text;
                studobj.State = txtstate.Text;
                studobj.City = txtcity.Text;
                studobj.Guardeanname = txtguardeanname.Text;
                studobj.Guardeanaddress = txtguardeanaddress.Text;
                studobj.Gmob = txtguardeanmobile.Text;
                studobj.Roomtype = dropdownroomtype.SelectedItem.Text;
                studobj.Email = txtemail.Text;
                string filename = Path.GetFileName(photo.PostedFile.FileName);
                string ext = Path.GetExtension(filename);
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".bmp" || ext.ToLower() == ".png" || ext.ToLower() == ".jpeg")
                {
                    string src = Server.MapPath("~/Photo") + "\\" + txtfname.Text + ".JPG";
                    photo.PostedFile.SaveAs(src);
                    string picpath = "~/Photo/" + txtfname.Text + ".JPG";
                    studobj.Photo = picpath;
                }
                studobj.Username = txtemail.Text.ToString();
                studobj.Password = txtmobile.Text.ToString();
                studobj.Usertype = "Student";
                studobj.InsertLogin();
                studobj.Registration();
                Response.Write("<script>alert(' successfully registered')</script>");
            }
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Assistantwarden/StudentRegistration");
        }
    }
}