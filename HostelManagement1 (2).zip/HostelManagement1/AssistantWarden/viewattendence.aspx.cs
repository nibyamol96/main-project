﻿using HostelManagement1.Class;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace HostelManagement1.AssistantWarden
{
    public partial class viewattendence : System.Web.UI.Page
    {
        markAttendance mobj = new markAttendance();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                mobj.FillGrid("select student_id, student.first_name+' '+last_name as first_name from student_registration", GridView1);
                TextBox1.Text = System.DateTime.Now.Date.ToShortDateString();
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            mobj.ReadData("select * from attendence where atdate='" + TextBox1.Text + "'");
            if (mobj.dr.Read())
            {
                Response.Write(mobj.MessageBox("Attendance already added for this date"));
            }
            else
            {
                foreach (GridViewRow grw in GridView1.Rows)
                {
                    RadioButtonList rbtn = (RadioButtonList)grw.Cells[2].Controls[0].FindControl("RadioButtonList1");
                    Label lblempid = (Label)grw.Cells[0].Controls[0].FindControl("Label1");
                    mobj.WriteData("insert into attendence values( '" + TextBox1.Text + "','" + lblempid.Text + "','" + rbtn.SelectedItem.Text + "')");
                }
                Response.Write(mobj.MessageBox("Attendance added successfully"));
                Server.Transfer("viewattendence.aspx");
            }
        }
    }
    }