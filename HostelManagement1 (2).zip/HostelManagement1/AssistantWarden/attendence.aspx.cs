﻿using HostelManagement1.Class;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HostelManagement1.AssistantWarden
{
    public partial class attendence : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                DataTable addstudent = new DataTable();
                markAttendance sObj = new markAttendance();
                addstudent = sObj.ExecuteSelectQueries();
                if (addstudent.Rows.Count > 0)
                {
                    attendancef.DataSource = addstudent;
                    attendancef.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            markAttendance mobj = new markAttendance();
                   foreach (GridViewRow gvr in attendancef.Rows)
            {
                if (((CheckBox)gvr.FindControl("attendence")).Checked == true)
                {

                    mobj.Ron = Convert.ToInt32(((HiddenField)gvr.FindControl("hdnRNo")).Value);
                    mobj.Student_id = Convert.ToInt32(Session["student_id"]);
                    mobj.MarkAbsent();

                }
            }

        }
    }
}