﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class FeesPayment : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select student.name,student.phone,allocation.floor,allocation.roomno,allocation.bedno,allocation.tmonths,payment.messamount as amount from allocation,student,payment where allocation.status='Allocated' and allocation.admno=student.admno and student.admno=payment.admno and month(payment.pdate)=" + ddlmonth.SelectedValue, GridView1);
        if (obj.dt.Rows.Count == 0)
        {
            lblamount.Text = "";
            Response.Write(obj.MessageBox("No Record Exists!!!"));
            Server.Transfer("FeesPayment.aspx");
        }
        else
        {
            obj.ReadData("select sum(payment.messamount) as amount from allocation,student,payment where allocation.status='Allocated' and allocation.admno=student.admno and student.admno=payment.admno and month(payment.pdate)=" + ddlmonth.SelectedValue.ToString());
            if (obj.dr.Read())
            {
                lblamount.Text = "Total Amount Rs. " + obj.dr.GetValue(0).ToString() + " /-";
            }
        }
    }
}