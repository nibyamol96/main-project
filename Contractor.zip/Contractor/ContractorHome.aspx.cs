﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Contractor_ContractorHomr : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        lbluname.Text = (String)Session["name"];
        lbldate.Text = System.DateTime.Now.Date.ToShortDateString();

        int LCount = 0, SCount = 0;
        obj.ReadData("select count(*) from leave_student,student where leave_student.admno=student.admno and '" + lbldate.Text + "' BETWEEN CONVERT(date,leave_student.fdate) and CONVERT(date,leave_student.tdate)");
        if (obj.dr.Read())
        {
            LCount = Convert.ToInt32(obj.dr.GetValue(0).ToString());
        }
        obj.ReadData("select count(*) from student");
        if (obj.dr.Read())
        {
            SCount = Convert.ToInt32(obj.dr.GetValue(0).ToString());
        }
        int TCount = SCount - LCount;
        lblcount.Text = "Total Students Present are " + TCount.ToString();
    }
}