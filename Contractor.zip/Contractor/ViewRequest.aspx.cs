﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Student_ViewRequest : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from Food_Request,student where Food_Request.uname=student.uname and Food_Request.contractor='" + (String)Session["uname"] + "' and Food_Request.status='Active'", GridView2);
        }
    }
    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        obj.FillDet("select floor,roomno,bedno from allocation where admno=" + e.CommandArgument.ToString(), DetailsView1);
    }
}