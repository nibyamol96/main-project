﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_addemployee : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    public static string ID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.ReadData("select ISNULL(max(id)+2,75875) from employee");
            if (obj.dr.Read())
            {
                ID = obj.dr.GetValue(0).ToString();
                txtemp.Text = "EMP/" + System.DateTime.Now.Year.ToString() + "/" + ID.ToString();
            }
            Panel1.Visible = true;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from employee");
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Warden Already Exists!!!')</script>");
        }
        else
        {
            if (ddldesig.SelectedValue == "3")
            {
                obj.WriteData("insert into employee values(" + ID + ",'" + txtemp.Text + "','" + txtfname.Text + "','" + txtlname.Text + "','" + RadioButtonList1.SelectedItem.Value + "','" + txtdob.Text + "','" + txthname.Text + "','" + txtloc.Text + "','" + txtpin.Text + "','" + txtjdate.Text + "','" + txtbsal.Text + "','" + ddldesig.SelectedItem.Value + "','" + FileUpload1.FileName + "'," + txtmob.Text + ",'" + txtmail.Text + "','')");
                Response.Write("<script>alert('employee details added successfully')</script>");
                Server.Transfer("addemployee.aspx");
            }
            else
            {
                obj.ReadData("select * from employee where mobile=" + txtmob.Text + "or email='" + txtmail.Text + "'or uname='" + txtuname.Text + "'");
                if (obj.dr.Read())
                {
                    Response.Write(obj.MessageBox("data already exists!!!"));
                }
                else
                {
                    if (FileUpload1.HasFile)
                    {
                        string ext = System.IO.Path.GetExtension(FileUpload1.FileName);
                        if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".JPG" || ext == ".JPEG" || ext == ".PNG")
                        {
                            FileUpload1.SaveAs(Server.MapPath("~/Photo/" + FileUpload1.FileName));
                            obj.WriteData("insert into login values('" + txtuname.Text + "','" + txtpwd.Text + "','" + ddldesig.SelectedItem.Text + "')");
                            obj.WriteData("insert into employee values(" + ID + ",'" + txtemp.Text + "','" + txtfname.Text + "','" + txtlname.Text + "','" + RadioButtonList1.SelectedItem.Value + "','" + txtdob.Text + "','" + txthname.Text + "','" + txtloc.Text + "','" + txtpin.Text + "','" + txtjdate.Text + "','" + txtbsal.Text + "','" + ddldesig.SelectedItem.Value + "','" + FileUpload1.FileName + "'," + txtmob.Text + ",'" + txtmail.Text + "','" + txtuname.Text + "')");
                            SentoMail();
                            Response.Write("<script>alert('employee details added successfully')</script>");
                            Server.Transfer("addemployee.aspx");
                        }
                        else
                        {
                            Response.Write("<script>alert('invalid extension')</script>");
                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('please upload a file')</script>");
                    }
                }
            }
        }
    }
    public static bool CheckForInternetConnection()
    {
        try
        {
            using (var client = new WebClient())
            {
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
        }
        catch
        {
            return false;
        }
    }
    protected void SentoMail()
    {
        bool VAL = CheckForInternetConnection();
        if (VAL == true)
        {
            string MailId = txtmail.Text;
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(MailId.ToString());

                mail.From = new MailAddress("webapplication003@gmail.com");
                mail.Subject = "HOSTEL MANAGEMENT SYSTEM";
                string Body = "USERNAME FOR LOGIN IS " + txtuname.Text + " AND YOUR PASSWORD IS " + txtpwd.Text;
                mail.Body = Body;
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                smtp.Port = 587;
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential
                ("webapplication003@gmail.com", "logicsoft");
                //Or your Smtp Email ID and Password
                smtp.EnableSsl = true;
                smtp.Send(mail);

                Response.Write("<script>alert('MESSAGE SEND TO THE EMAIL')</script>");
            }
            catch (Exception ex)
            {
                // result = "Error sending email.!!!" + ex;
                Response.Write("<script>alert('No Internet Connection To send Confirmation Email')</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('No Internet Connection')</script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("addemployee.aspx");
    }
    protected void txtdob_TextChanged(object sender, EventArgs e)
    {
        if (txtdob.Text != "")
        {
            DateTime yr = Convert.ToDateTime(txtdob.Text);
            double y = yr.Year;
            double cr = System.DateTime.Now.Year;
            double diff = cr - y;
            if (diff < 18 || diff > 50)
            {
                Response.Write("<script>alert('invalid date')</script>");
            }
        }
    }
    protected void txtmob_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txtjdate_TextChanged(object sender, EventArgs e)
    {
        DateTime jdate = Convert.ToDateTime(txtjdate.Text);
        if (jdate > Convert.ToDateTime(System.DateTime.Now.Date))
        {
            // txtjdate.Text = System.DateTime.Now.Date.ToShortDateString();
            Response.Write(obj.MessageBox("Invalid  Date"));
        }
    }
    protected void ddldesig_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddldesig.SelectedValue == "3")
        {
            Panel1.Visible = false;
        }
        else
        {
            Panel1.Visible = true;
        }
    }
}