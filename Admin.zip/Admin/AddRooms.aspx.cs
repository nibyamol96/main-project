﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Admin_Rooms11 : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            for (int i = 0; i <= 10; i++)
            {
                ddlfloorno.Items.Add(i.ToString());
            }
        }
    }
    protected void room_number_TextChanged(object sender, EventArgs e)
    {
        obj.ReadData("select * from roomdetails where roomno='" + room_number.Text + "'");
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Room No. Already Exists...!')</script>");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from roomdetails where roomno='" + room_number.Text + "'");
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Room No. Already Exists...!')</script>");
        }
        else
        {
            obj.WriteData("insert into roomdetails values('" + room_number.Text + "','" + ddlfloorno.SelectedItem.Text + "','" + ddlusers.SelectedItem.Text + "','" + rate_perday.Text + "','" + facilities.Text + "','AVAILABLE')");
            foreach (ListItem li in ListBox1.Items)
            {
                obj.WriteData("insert into beddetails values('" + li.Text + "','" + room_number.Text + "','AVAILABLE')");
            }
            Response.Write("<script>alert('Room Details Added Successfully')</script>");
            Server.Transfer("AddRooms.aspx");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("AddRooms.aspx");
    }
    protected void ddlusers_SelectedIndexChanged(object sender, EventArgs e)
    {
        ListBox1.Items.Clear();
        if (ddlusers.SelectedIndex != 0)
        {
            for (int i = 1; i <= Convert.ToInt32(ddlusers.SelectedItem.Text); i++)
            {
                ListBox1.Items.Add("BN-" + i.ToString());
            }
        }
    }
}