﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_addcategory : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Hostel obj = new Hostel();
        obj.ReadData("select * from food where fname='" + txtfname.Text + "'");
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Food Name Already Exist')</script>");
        }
        else
        {
            obj.WriteData("insert into food values('" + txtfname.Text + "','" + RadioButtonList1.SelectedItem.Text + "','" + txtrate.Text + "')");
            Response.Write("<script>alert('Food Details Added Successfully')</script>");
            Server.Transfer("AddFood.aspx");
        }
    }
}