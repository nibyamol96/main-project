﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_adminapproveleave : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select employee.fname+' '+lname as empname,leave_application.* from employee inner join leave_application on employee.empid=leave_application.empid and leave_application.status='pending'", GridView1);
        }
    }

    protected void LinkButton1_Command(object sender, CommandEventArgs e)
    {
        obj.WriteData("update leave_application set status='approved' where lvid=" + e.CommandArgument.ToString());
        Response.Write(obj.MessageBox("Leave Request Approved"));
        Server.Transfer("adminapproveleave.aspx");
    }
    protected void LinkButton5_Command(object sender, CommandEventArgs e)
    {
        obj.WriteData("update leave_application set status=' Not approved' where lvid=" + e.CommandArgument.ToString());
        Response.Write(obj.MessageBox("Leave Request NotApproved"));
        Server.Transfer("adminapproveleave.aspx");
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}