﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Warden_SearchStudent : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FoodDetails();
        }
    }
    protected void FoodDetails()
    {
        obj.FillGrid("select * from food", GridView1);
    }
    protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView1.EditIndex = -1;
        FoodDetails();
    }
    protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView1.EditIndex = e.NewEditIndex;
        FoodDetails();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        TextBox txtfname = (TextBox)GridView1.Rows[e.RowIndex].Cells[0].Controls[0];
        RadioButtonList rbtn = (RadioButtonList)GridView1.Rows[e.RowIndex].Cells[1].Controls[0].FindControl("RadioButtonList1");
        TextBox txtrate = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
        obj.WriteData("update food set fname='" + txtfname.Text + "',type='" + rbtn.SelectedItem.Text + "',rate=" + txtrate.Text + " where fid=" + GridView1.DataKeys[e.RowIndex].Value);
        Server.Transfer("ViewFood.aspx");
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        obj.WriteData("delete from food where fid=" + GridView1.DataKeys[e.RowIndex].Value);
        Server.Transfer("ViewFood.aspx");
    }
}