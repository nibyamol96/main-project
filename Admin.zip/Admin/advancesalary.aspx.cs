﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_advancesalary : System.Web.UI.Page
{
   
    Hostel obj = new Hostel();
    public string empid="";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.adapter("select fname+' '+lname as empname,empid from employee");
            ddlemp.DataSource = obj.dt;
            ddlemp.DataTextField = "empname";
            ddlemp.DataValueField = "empid";
            ddlemp.DataBind();
            ddlemp.Items.Insert(0, "-Select Employee-");
        }
        txtdate.Text = System.DateTime.Now.ToShortDateString();
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into adv_sal values('" + ddlemp.SelectedItem.Value + "','" + txtdate.Text + "','" + txtsalad.Text + "')");
        Response.Write(obj.MessageBox(" details Added Successfully"));
        Server.Transfer("advancesalary.aspx");
    }
    protected void txtsalad_TextChanged(object sender, EventArgs e)
    {
        double ba = Convert.ToDouble(txtba.Text);
        double sad = Convert.ToDouble(txtsalad.Text);
        if (sad > ba)
        {
            Response.Write(obj.MessageBox("Invalid datas"));
        }
        else
        {
            double balance = ba - sad;
            txtbalance.Text = Convert.ToString(balance);
        }
    }
    protected void ddlemp_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlemp.SelectedIndex != 0)
        {
            obj.ReadData("select basalary,designation from employee where empid='" +ddlemp.SelectedValue  +"'");
            if (obj.dr.Read())
            {
                txtba.Text = obj.dr["basalary"].ToString();
                txtdetails.Text =  obj.dr["basalary"].ToString() + Environment.NewLine + obj.dr["designation"].ToString();
            }
        }
        else
        {
            Response.Write(obj.MessageBox("Select a employee"));
            txtdetails.Text = "";
        }
    }
    protected void txtba_TextChanged(object sender, EventArgs e)
    {
        
        
        
    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        Server.Transfer("advancesalary.aspx");
    }
}