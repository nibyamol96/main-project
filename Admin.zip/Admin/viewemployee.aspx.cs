﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_viewemployee : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select '~/Photo/'+employee.photo as im,employee.empid, employee.fname+' '+lname as empname,employee.gender,employee.location,employee.jdate,employee.designation,employee.mobile, employee.email, employee.photo from employee", GridView1);
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string uname = "";
        obj.ReadData("select uname from employee where empid='" + GridView1.DataKeys[e.RowIndex].Value + "'");
        if (obj.dr.Read())
        {
            uname = obj.dr.GetValue(0).ToString();
        }
        obj.WriteData("delete from employee where empid='" + GridView1.DataKeys[e.RowIndex].Value + "'");
        obj.WriteData("delete from login where uname='" + uname + "'");
        Server.Transfer("viewemployee.aspx");
    }
}