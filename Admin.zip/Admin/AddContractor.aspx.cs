﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class staff_employeedetails : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from login where uname='" + txtuname.Text + "'");
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Username already exist')</script>");
        }
        else
        {
            FileUpload1.SaveAs(Server.MapPath("~/Photo/" + FileUpload1.FileName));
            obj.WriteData("insert into contractor values('" + txtfname.Text + "','" + txtlname.Text + "','" + rb.SelectedItem.Text + "','" + txthname.Text + "','" + txtlocation.Text + "','" + txtemail.Text + "'," + txtphone.Text + ",'" + txtuname.Text + "','" + FileUpload1.FileName + "')");
            obj.WriteData("insert into login values('" + txtuname.Text + "','" + txtpwd.Text + "','Contractor')");
            Response.Write("<script>alert('Contractor Registered successfully')</script>");
            Server.Transfer("AddContractor.aspx");
        }
    }
}