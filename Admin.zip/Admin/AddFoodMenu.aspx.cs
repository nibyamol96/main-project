﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddFoodMenu : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    public static DataTable dt = new DataTable();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Panel1.Visible = false;
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from tempfood where session='" + ddlsession.SelectedItem.Text + "' and fid=" + ddlfoodname.SelectedValue);
        if (obj.dr.Read())
        {
            Response.Write("<script>alert('Food Details for this Session Already Exist')</script>");
        }
        else
        {
            obj.WriteData("insert into tempfood values('" + ddlsession.SelectedItem.Text + "'," + ddlfoodname.SelectedValue + ",'" + ddlfoodname.SelectedItem.Text + "')");
            obj.FillGrid("select * from tempfood", GridView1);
            Panel1.Visible = true;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Server.Transfer("AddFoodMenu.aspx");
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        obj.WriteData("delete from tempfood where tfid=" + GridView1.DataKeys[e.RowIndex].Value);
        obj.FillGrid("select * from tempfood", GridView1);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        obj.ReadData("select * from foodmenu where fday='" + ddlday.SelectedItem.Text + "'");
        if (obj.dr.Read())
        {
            string fmid = "";
            fmid = obj.dr["fmid"].ToString();
            obj.adapter("select * from tempfood");
            dt = obj.dt;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                obj.WriteData("update foodmenudetails set fid=" + dt.Rows[i][2].ToString() + " where fmid=" + fmid + " and session='" + dt.Rows[i][1].ToString() + "'");
            }
            Response.Write("<script>alert('Food Details Updated Successfully')</script>");
        }
        else
        {
            obj.adapter("select * from tempfood");
            dt = obj.dt;
            string fmid = "";
            obj.WriteData("delete from tempfood");
            obj.WriteData("insert into foodmenu values('" + ddlday.SelectedItem.Text + "')");
            obj.ReadData("select max(fmid) from foodmenu");
            if (obj.dr.Read())
            {
                fmid = obj.dr.GetValue(0).ToString();
            }
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                obj.WriteData("insert into foodmenudetails values(" + fmid + ",'" + dt.Rows[i][1].ToString() + "'," + dt.Rows[i][2].ToString() + ")");
            }
            Response.Write("<script>alert('Food Details Added Successfully')</script>");
            Server.Transfer("AddFoodMenu.aspx");
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        obj.FillDropDownList("fname", "fid", "food", "type='" + RadioButtonList1.SelectedItem.Text + "'", ddlfoodname);
    }
}