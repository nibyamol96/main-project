﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Staff_ViewStudentAttendance : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select *,employee.fname+' '+employee.lname as name from empattendence,employee where empattendence.empid=employee.empid and empattendence.atdate='" + TextBox1.Text + "'", GridView1);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(TextBox1.Text);
        obj.FillGrid("select *,employee.fname+' '+employee.lname as name from empattendence,employee where empattendence.empid=employee.empid and month(empattendence.atdate)='" + dtm.Month + "'", GridView1);
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        DateTime dtm = Convert.ToDateTime(TextBox1.Text);
        obj.FillGrid("select *,employee.fname+' '+employee.lname as name from empattendence,employee where empattendence.empid=employee.empid and year(empattendence.atdate)='" + dtm.Year + "'", GridView1);
    }
}