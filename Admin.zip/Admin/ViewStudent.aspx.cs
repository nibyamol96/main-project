﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Warden_SearchStudent : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select * from allocation,Student where allocation.admno=student.admno and allocation.status='Allocated'", GridView1);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        obj.FillGrid("select * from allocation,Student where allocation.admno=student.admno and Student.course='" + ddl_course.SelectedItem.Text + "' and Student.sem='" + ddl_sem.SelectedItem.Text + "' and allocation.status='Allocated'", GridView1);
        if (obj.dt.Rows.Count == 0)
        {
            Response.Write(obj.MessageBox("No Record Exists!!!"));
        }
    }
}