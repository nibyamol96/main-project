﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_salarypayment : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.adapter("select fname+' '+lname as empname,empid from employee");
            ddlemp.DataSource = obj.dt;
            ddlemp.DataTextField = "empname";
            ddlemp.DataValueField = "empid";
            ddlemp.DataBind();
            ddlemp.Items.Insert(0, "-Select Employee-");
        }

        TextBox1.Text = System.DateTime.Now.ToShortDateString();
    }

    protected void ddlemp_SelectedIndexChanged(object sender, EventArgs e)
    {
        obj.ReadData("select basalary from employee where empid='" + ddlemp.SelectedValue + "'");
        if (obj.dr.Read())
        {
            txtsal.Text = obj.dr["basalary"].ToString();
        }
        obj.ReadData("select advance from adv_sal where empid='" + ddlemp.SelectedValue + "' and month(sdate)=" + System.DateTime.Now.Month.ToString());
        if (obj.dr.Read())
        {
            txtsalad.Text = obj.dr["advance"].ToString();
        }
        else
        {
            txtsalad.Text = "0";
        }
        int lcount = 0;
        obj.ReadData("select COUNT(*) from leave_application where empid='" + ddlemp.SelectedItem.Text + "' and MONTH(date)=" + System.DateTime.Now.Month.ToString());
        if (obj.dr.Read())
        {
            lcount = Convert.ToInt32(obj.dr.GetValue(0).ToString());
        }
        if (lcount > 2)
        {
            txtlv.Text = Convert.ToString(lcount - 2);
        }
        else
        {
            txtlv.Text = "0";
        }
        double Salary = 0.0, TA = 0.0, DA = 0.0, HRA = 0.0, Deduction = 0.0, Total;
        Salary = Convert.ToDouble(txtsal.Text) - Convert.ToDouble(txtsalad.Text);
        TA = .2 * Salary;
        txtta.Text = TA.ToString();
        DA = .4 * Salary;
        txtda.Text = DA.ToString();
        HRA = .5 * Salary;
        txthr.Text = HRA.ToString();
        Deduction = (Salary / 30) * lcount;
        Total = (TA + DA + HRA + Salary) - Deduction;
        txtdeduction.Text = Deduction.ToString();
        txttotalsalary.Text = Total.ToString();
    }
    protected void txtsal_TextChanged(object sender, EventArgs e)
    {

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        obj.WriteData("insert into salary_payment values('" + ddlemp.SelectedItem + "','" + TextBox1.Text + "','" + txtda.Text + "','" + txtta.Text + "','" + txthr.Text + "','" + txtdeduction.Text + "','" + txtsal.Text + "')");
        Response.Write(obj.MessageBox("salary details Added Successfully"));
        Server.Transfer("salarypayment.aspx");
    }
}