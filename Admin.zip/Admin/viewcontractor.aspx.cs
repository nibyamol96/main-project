﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_viewemployee : System.Web.UI.Page
{
    Hostel obj = new Hostel();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillGrid("select *,fname+' '+lname as name,'~/Photo/'+photo as im from contractor", GridView1);
        }
    }
    protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        string uname = "";
        obj.ReadData("select uname from contractor where cnid='" + GridView1.DataKeys[e.RowIndex].Value + "'");
        if (obj.dr.Read())
        {
            uname = obj.dr.GetValue(0).ToString();
        }
        obj.WriteData("delete from contractor where cnid='" + GridView1.DataKeys[e.RowIndex].Value + "'");
        obj.WriteData("delete from login where uname='" + uname + "'");
        Server.Transfer("viewcontractor.aspx");
    }
}