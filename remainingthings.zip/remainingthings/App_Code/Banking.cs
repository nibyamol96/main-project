﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI;


public class Banking
{
    public SqlConnection con = new SqlConnection();
    public SqlCommand cmd;
    public SqlDataReader dr;
    public SqlDataAdapter ad = new SqlDataAdapter();
    public DataTable dt = new DataTable();
    public DataSet ds = new DataSet();

    protected void GetConnection()
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = ConfigurationManager.AppSettings["Hostel"];
        con.Open();
    }

    public void ReadData(string sql)
    {
        GetConnection();
        cmd = new SqlCommand(sql, con);
        dr = cmd.ExecuteReader();
    }

    public void WriteData(string sql)
    {
        GetConnection();
        cmd = new SqlCommand(sql, con);
        cmd.ExecuteNonQuery();
    }


    public void FillDropDownList(string text, string value, string table, string condition, DropDownList ddllst)
    {
        if (condition == "")
        {
            string SQL = "select " + text + "," + value + " from " + table;
            GetConnection();
            dt.Rows.Clear();
            cmd = new SqlCommand(SQL, con);
            ad.SelectCommand = cmd;
            ad.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddllst.DataSource = dt;
                ddllst.DataTextField = text;
                ddllst.DataValueField = value;
                ddllst.DataBind();
            }
        }
        else
        {
            string SQL = "select " + text + "," + value + " from " + table + " where " + condition;
            GetConnection();
            dt.Rows.Clear();
            cmd = new SqlCommand(SQL, con);
            ad.SelectCommand = cmd;
            ad.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                ddllst.DataSource = dt;
                ddllst.DataTextField = text;
                ddllst.DataValueField = value;
                ddllst.DataBind();
            }
        }
        ddllst.Items.Insert(0, "--select--");
    }

    public int PK_Generation(string PK, string Table)
    {
        Random rd = new Random();
        int value = (int)rd.Next(2000, 7000);
        string SQL = "select ISNULL(MAX(" + PK + ")+1," + value + ") from " + Table;
        GetConnection();
        cmd = new SqlCommand(SQL, con);
        int PrimaryKey = Convert.ToInt32(cmd.ExecuteScalar());
        return PrimaryKey;
    }

    public string Messagebox(string Msg)
    {
        string Message = "<script> alert('" + Msg + "') </script>";
        return Message;
    }

    public void Adapter(string sql)
    {
        dt.Rows.Clear();
        GetConnection();
        cmd = new SqlCommand(sql, con);
        ad.SelectCommand = cmd;
        ad.Fill(dt);
    }
}