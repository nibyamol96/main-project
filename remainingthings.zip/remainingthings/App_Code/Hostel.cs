﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Data;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for DigitalWaterMarking
/// </summary>

public class Hostel
{
    public SqlConnection con = new SqlConnection();
    public SqlCommand cmd;
    public SqlDataAdapter da = new SqlDataAdapter();
    public SqlDataReader dr;
    public DataTable dt = new DataTable();
    public SqlCommand cmdsp = new SqlCommand();
    protected void dbconnection()
    {
        if (con.State == ConnectionState.Open)
        {
            con.Close();
        }
        con.ConnectionString = WebConfigurationManager.AppSettings["Hostel"];
        con.Open();
    }

    public void StoredProcedureExe(string spname)
    {
        try
        {
            dbconnection();
            cmdsp.Connection = con;
            cmdsp.CommandType = CommandType.StoredProcedure;
            cmdsp.CommandText = spname;
            cmdsp.ExecuteNonQuery();
        }
        catch (Exception ex)
        { 
        
        }
    }

    public void WriteData(string sql)
    {
        dbconnection();
        cmd = new SqlCommand(sql, con);
        cmd.ExecuteNonQuery();
    }
    public void ReadData(string sql)
    {
        dbconnection();
        cmd = new SqlCommand(sql, con);
        dr = cmd.ExecuteReader();
    }
    public void adapter(string sql)
    {
        dt.Rows.Clear();
        dbconnection();
        cmd = new SqlCommand(sql, con);
        da.SelectCommand = cmd;
        da.Fill(dt);
    }
    public void FillDropDownList(string Text, string Value, string Table, string Condition, DropDownList ddlst)
    {
        if (Condition == "")
        {
            string sql = "select distinct " + Value + "," + Text + " from " + Table + "";
            adapter(sql);
            if (dt.Rows.Count > 0)
            {
                ddlst.DataSource = dt;
                ddlst.DataTextField = Text;
                ddlst.DataValueField = Value;
                ddlst.DataBind();
            }
        }
        else
        {
            string sql = "select distinct " + Text + "," + Value + " from " + Table + " where " + Condition + "";

            adapter(sql);
            if (dt.Rows.Count > 0)
            {
                ddlst.DataSource = dt;
                ddlst.DataTextField = Text;
                ddlst.DataValueField = Value;
                ddlst.DataBind();
            }
        }
        ddlst.Items.Insert(0, "---Select---");
    }
    public void FillGrid(string sql, GridView grdvw)
    {
        adapter(sql);
        if (dt.Rows.Count > 0)
        {
            grdvw.DataSource = dt;
            grdvw.DataBind();
        }
    }
    public void FillDataList(string sql, DataList dtlst)
    {
        adapter(sql);
        if (dt.Rows.Count > 0)
        {
            dtlst.DataSource = dt;
            dtlst.DataBind();
        }
    }
    public void FillDet(string sql, DetailsView detvw)
    {
        adapter(sql);
        if (dt.Rows.Count > 0)
        {
            detvw.DataSource = dt;
            detvw.DataBind();
        }
    }
    public DataTable FetchData(string sql)
    {
        dbconnection();
        dt.Rows.Clear();
        cmd = new SqlCommand(sql, con);
        da.SelectCommand = cmd;
        da.Fill(dt);
        return dt;
    }
    public string MessageBox(string msg)
    {
        string Message = "<script>alert('" + msg + "')</script>";
        return Message;
    }
}