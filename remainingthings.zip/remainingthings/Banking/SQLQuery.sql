CREATE TABLE [dbo].[account](
	[id] [int] IDENTITY(100,1) NOT NULL,
	[bankid] [int] NULL,
	[branchid] [int] NULL,
	[cardno] [bigint] NULL,
	[cardholder] [varchar](50) NULL,
	[cvv] [int] NULL,
	[expmonth] [int] NULL,
	[expyear] [int] NULL,
	[amount] [numeric](18, 2) NULL,
 CONSTRAINT [PK_account] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[bank](
	[bankid] [int] IDENTITY(4000,1000) NOT NULL,
	[bname] [varchar](50) NULL,
	[logo] [varchar](50) NULL,
 CONSTRAINT [PK_bank] PRIMARY KEY CLUSTERED 
(
	[bankid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

CREATE TABLE [dbo].[transactions](
	[trid] [bigint] IDENTITY(100000000,1) NOT NULL,
	[tdate] [varchar](50) NULL,
	[cardno] [bigint] NULL,
	[amount] [numeric](18, 2) NULL,
 CONSTRAINT [PK_transaction] PRIMARY KEY CLUSTERED 
(
	[trid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[branch](
	[branchid] [int] IDENTITY(15000,1) NOT NULL,
	[bankid] [int] NULL,
	[brname] [varchar](50) NULL,
	[address] [varchar](1000) NULL,
	[phone] [bigint] NULL,
	[ifsc] [varchar](50) NULL,
 CONSTRAINT [PK_branch] PRIMARY KEY CLUSTERED 
(
	[branchid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

SET IDENTITY_INSERT [dbo].[account] ON 

GO
INSERT [dbo].[account] ([id], [bankid], [branchid], [cardno], [cardholder], [cvv], [expmonth], [expyear], [amount]) VALUES (100, 4000, 15000, 1212121212121212, N'Vishnu R', 122, 12, 2029, CAST(4859750.00 AS Numeric(18, 2)))
GO
INSERT [dbo].[account] ([id], [bankid], [branchid], [cardno], [cardholder], [cvv], [expmonth], [expyear], [amount]) VALUES (101, 4000, 15000, 1111111111111111, N'Administrator', 155, 12, 2029, CAST(246250.00 AS Numeric(18, 2)))
GO
SET IDENTITY_INSERT [dbo].[account] OFF
GO
SET IDENTITY_INSERT [dbo].[bank] ON 

GO
INSERT [dbo].[bank] ([bankid], [bname], [logo]) VALUES (4000, N'State Bank of India', N'sbi.jpg')
GO
INSERT [dbo].[bank] ([bankid], [bname], [logo]) VALUES (5000, N'South Indian Bank', N'sib.jpg')
GO
INSERT [dbo].[bank] ([bankid], [bname], [logo]) VALUES (6000, N'Federal Bank', N'federal.png')
GO
INSERT [dbo].[bank] ([bankid], [bname], [logo]) VALUES (7000, N'HDFC Bank', N'hdfc.jpg')
GO
SET IDENTITY_INSERT [dbo].[bank] OFF
GO
SET IDENTITY_INSERT [dbo].[branch] ON 

GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15000, 4000, N'Kottayam', N'SBI Kottayam
686001', 9447142514, N'SB34322323')
GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15001, 5000, N'Ettumanoor', N'SIB Ettumanoor
686632', 9744251427, N'SIB342233')
GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15002, 4000, N'Karuputtate', N'SBIArpookara625485', 9447154154, N'SBI254687')
GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15003, 6000, N'Kumaranelloor', N'FBKottayam686524', 9867545623, N'FB25487545')
GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15004, 7000, N'Thiruvalla', N'HDFCThiruvalla685652', 9541254658, N'HDFC254587')
GO
INSERT [dbo].[branch] ([branchid], [bankid], [brname], [address], [phone], [ifsc]) VALUES (15005, 6000, N'Chungam', N'FBKottayam686059', 9447147414, N'Fb254687')
GO
SET IDENTITY_INSERT [dbo].[branch] OFF