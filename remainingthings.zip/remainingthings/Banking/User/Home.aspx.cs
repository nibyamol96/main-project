﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_SelectBank : System.Web.UI.Page
{
    Banking obj = new Banking();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            obj.FillDropDownList("bname", "bankid", "bank", "", ddlbankname);
        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {

    }

    protected void ddlbankname_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlbankname.SelectedIndex != 0)
        {
            obj.FillDropDownList("brname", "branchid", "branch", "bankid=" + ddlbankname.SelectedItem.Value, ddlbranch);
        }
        else
        {
            ddlbranch.Items.Clear();
            lblmsg.Text = "Please Select a Bank";
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["bankid"] = ddlbankname.SelectedItem.Value;
        Session["branchid"] = ddlbranch.SelectedItem.Value;
        Response.Redirect("DebitCard.aspx");
    }
}