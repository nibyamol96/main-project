﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class MoneyTransfer : System.Web.UI.Page
{
    Banking obj = new Banking();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {            
            lblDate.Text = System.DateTime.Now.Date.ToShortDateString();
            TimeSpan timespan = new TimeSpan(System.DateTime.Now.TimeOfDay.Hours, System.DateTime.Now.TimeOfDay.Minutes, System.DateTime.Now.TimeOfDay.Seconds);
            DateTime time = DateTime.Today.Add(timespan);
            lbltime.Text = time.ToString("hh:mm tt");
            //lbltime.Text = System.DateTime.Now.TimeOfDay.Hours.ToString()+":"+ System.DateTime.Now.TimeOfDay.Minutes.ToString()+" "+ System.DateTime.Now.Times
            lblname.Text = (String)Session["cardholder"];
            lblbalance.Text = (String)Session["balance"];
            lblamount.Text = (String)Session["amount"];
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Banking obj = new Banking();
        obj.ReadData("select cardholder,amount from account where bankid=" + (String)Session["bankid"] + " and branchid=" + (String)Session["branchid"] + " and cardno=" + (String)Session["cardno"] + " and amount>" + lblamount.Text);
        if (obj.dr.Read())
        {
            lblmsg.Text = "";
            obj.WriteData("insert into transactions values('" + lblDate.Text + "'," + (String)Session["cardno"] + "," + lblamount.Text + ")");
            obj.WriteData("update account set amount = amount + " + lblamount.Text + " where bankid = 4000 and branchid = 15000 and cardno = 1111111111111111");
            obj.WriteData("update account set amount = amount - " + lblamount.Text + " where bankid = " + (String)Session["bankid"] + " and branchid=" + (String)Session["branchid"] + " and cardno=" + (String)Session["cardno"]);
            obj.ReadData("select max(trid) from transactions");
            if(obj.dr.Read())
            {
                Session["trid"] = obj.dr.GetValue(0).ToString();
            }
            Response.Redirect("transactions.aspx");
            //update account set amount = amount - 1 where bankid = 4000 and branchid = 15000 and cardno = 1111111111111111
        }
        else
        {
            lblmsg.Text = "Insufficient Balance!!!";
        }
    }
}