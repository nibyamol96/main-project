﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.MasterPage
{
    Banking obj = new Banking();
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetNoStore();
        string s = (String)Session["bankid"];
        if ((String)Session["bankid"] == null && (String)Session["branchid"] == null)
        {
            Response.Redirect("Home.aspx");
        }
        else
        {
            if (!IsPostBack)
            {
                obj.ReadData("select '~/Banking/logo/'+logo as im from bank where bankid=" + (String)Session["bankid"]);
                if (obj.dr.Read())
                {
                    Image1.ImageUrl = obj.dr["im"].ToString();
                }
            }
        }
    }
}
