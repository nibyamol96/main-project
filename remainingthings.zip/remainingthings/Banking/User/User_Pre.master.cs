﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //Session["bankid"] = null;
            //Session["branchid"] = null;
            //Session["trid"] = null;
            //Session["cardno"] = null;
            //Session["cardholder"] = null;
            //Session.Abandon();
        }
    }
}
