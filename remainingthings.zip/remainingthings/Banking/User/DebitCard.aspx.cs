﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DebitCard : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            for (int i = 1; i <= 12; i++)
            {
                ddlmonth.Items.Add(i.ToString());
            }
            int YR = System.DateTime.Now.Year;
            YR = YR + 1;
            for (int i = YR; i <= 2030; i++)
            {
                ddlyear.Items.Add(i.ToString());
            }
            ddlmonth.Items.Insert(0, "--MM--");
            ddlyear.Items.Insert(0, "--YYYY--");
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Banking obj = new Banking();
        obj.ReadData("select cardholder,amount from account where bankid=" + (String)Session["bankid"] + " and branchid=" + (String)Session["branchid"] + " and cardno=" + txtcardno.Text + " and cvv=" + txtcvv.Text + " and expmonth=" + ddlmonth.SelectedItem.Text + " and expyear=" + ddlyear.SelectedItem.Text);
        if (obj.dr.Read())
        {
            Session["cardno"] = txtcardno.Text;
            Session["cardholder"] = obj.dr["cardholder"].ToString();
            Session["balance"] = obj.dr["amount"].ToString();
            Response.Redirect("MoneyTransfer.aspx");
        }
        else
        {
            Response.Write(obj.Messagebox("Invalid Card Details...Cannot Proceed!!!"));
        }
    }
}