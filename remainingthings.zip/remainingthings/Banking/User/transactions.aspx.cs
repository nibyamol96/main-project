﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class transactions : System.Web.UI.Page
{
    Banking obj = new Banking();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            TransactionDetails();
        }
    }
    protected void TransactionDetails()
    {
        obj.ReadData("select cardholder,amount from account where bankid=" + (String)Session["bankid"] + " and branchid=" + (String)Session["branchid"] + " and cardno=" + (String)Session["cardno"]);
        if (obj.dr.Read())
        {
            lblcardholder.Text = obj.dr["cardholder"].ToString();
            lblbalance.Text = obj.dr["amount"].ToString();
        }
        obj.Adapter("select account.cardholder,account.cardno,transactions.tdate,transactions.amount from transactions,account where transactions.cardno=account.cardno and transactions.trid=" + (String)Session["trid"]);
        if (obj.dt.Rows.Count > 0)
        {
            GridView_Current.DataSource = obj.dt;
            GridView_Current.DataBind();
        }
        obj.Adapter("select account.cardholder,account.cardno,transactions.tdate,transactions.amount from transactions,account where transactions.cardno=account.cardno order by transactions.trid desc");
        if (obj.dt.Rows.Count > 0)
        {
            GridView_Previous.DataSource = obj.dt;
            GridView_Previous.DataBind();
        }
    }
}